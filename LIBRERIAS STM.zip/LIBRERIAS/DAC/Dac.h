// C�digo Ejemplo 12 2 // 
// Archivo *.h //
#ifndef _DAC_H
#define _DAC_H
#include "Pines.h"
#if defined(STM32F746xx) // C�digo solo para F746
 // Clase DAC // 
class Dac{
private:
 Pines C1,C2; // Pines an�logos
public:
 void Iniciar(bool dac1,bool dac2); // M�todo para iniciar canales
 void Can1Bit12(unsigned int v); // Set dato en canal 1 a 12 bits
 void Can2Bit12(unsigned int v); // Set dato en canal 2 a 12 bits
  // Set dato en canal 1 y 2 a 12 bits
 void CanBit12(unsigned int v1,unsigned int v2);
 void Can1Bit8(unsigned char v); // Set dato en canal 1 a 8 bits
 void Can2Bit8(unsigned char v); // Set dato en canal 2 a 8 bits
  // Set dato en canal 1 y 2 a 8 bits
 void CanBit8(unsigned char v1,unsigned char v2);
};
#endif
#endif 





