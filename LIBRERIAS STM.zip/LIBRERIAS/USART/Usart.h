// C�digo Ejemplo 13 2 //
// Archivo *.h //
#ifndef _USART_H
#define _USART_H
#include "Pines.h"
 //  *** Clase Usart ***  // 
class Usart{
private:
 Pines TX,RX;
 USART_TypeDef *port; // Estructura de USART
 unsigned char prt;
public:
  // M�todo para iniciar puerto serial
 void Iniciar(unsigned char rx,unsigned char tx,unsigned int bps);
 void Interrupcion(FunInt2 fun); // M�todo para asignar interrupci�n de Rx
 void TxDato(unsigned char d); // M�todo para transmitir un dato
 bool RxListo(void); // M�todo para verificar si llego un dato
 unsigned char RxDato(void); // M�todo para leer un dato
 unsigned char operator = (unsigned char d); // Operador para enviar dato
 void operator = (char *t); // Operador para enviar cadena de texto
 operator unsigned char(); // Operador para esperar un dato
 void operator = (FunInt2 fun); // Operador para asignar interrupci�n de Rx
};
#endif


