// C�digo Ejemplo 16 16 // 
// Archivo *.cpp //
#include "Encoder.h"

 // M�todo para iniciar Encoder
void Encoder::IniciarEncoder(unsigned char tmr,unsigned char a,unsigned char b){
 Pines AB; // Objeto Pin
 SetTimer(tmr); // Inicia Timer
  // Configura pines en canales 1 y 2
 AB.FuncionAlternativa(a,1);AB.PullUp();
 AB.FuncionAlternativa(b,1);AB.PullUp();
 t->ARR=0xFFFF; // Asigna m�ximo conteo al Timer
  // Configura Modo Encoder
 t->CCMR1|=TIM_CCMR1_CC1S_0;
 t->CCMR1|=TIM_CCMR1_CC2S_0;
  // Activa entradas canal 1 y 2
 t->CCER&=~(TIM_CCER_CC2P|TIM_CCER_CC1P);
 t->SMCR|=3UL;
 t->CNT=32768; // Inicia Timer en valor central
 PosEncoder=0; // Inicia conteo en 0
}

 // M�todo para leer Encoder diferencial
int Encoder::GetDiferencial(void){
 int dif;
  // Calcula la diferencia
 dif=32768-(int)t->CNT;
 t->CNT=32768; // Inicia Timer en valor central
 return dif; // Retorna valor
}

 // M�todo para leer Encoder Absoluto
int Encoder::GetAbsoluto(void){
  // Incrementa posici�n del Encoder
  // con la diferencial actual
 PosEncoder+=GetDiferencial();
 return PosEncoder; // Retorna valor de posici�n
}

