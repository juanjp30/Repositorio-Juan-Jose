// C�digo Ejemplo 16 15 // 
// Archivo *.h //
#ifndef _ENCODER_H
#define _ENCODER_H
#include "Timer.h"
// *** Clase Encoder *** //
class Encoder : public Timer{
private:
 int PosEncoder; // Variable de conteo del Encoder
public:
  // M�todo para iniciar Encoder  
 void IniciarEncoder(unsigned char tmr,unsigned char a,unsigned char b);
  // M�todo para leer Encoder diferencial
 int GetDiferencial(void);
  // M�todo para leer Encoder Absoluto
 int GetAbsoluto(void);
};
#endif

