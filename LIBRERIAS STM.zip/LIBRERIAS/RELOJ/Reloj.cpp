// C�digo Ejemplo 6 10//
// Archivo *.cpp //
#include "Reloj.h"

void Reloj::SetHSION(bool e){ // M�todo para activar HSI
 if(e){
  RCC->CR |= RCC_CR_HSION;
  while(!(RCC->CR&RCC_CR_HSIRDY));
 }
 else
  RCC->CR &= ~RCC_CR_HSION;
}

void Reloj::SetHSEON(bool e){ // M�todo para activar HSE   
 if(e){
  RCC->CR |= RCC_CR_HSEON;
  while(!(RCC->CR&RCC_CR_HSERDY));
 }
 else
  RCC->CR &= ~RCC_CR_HSEON;
}
 
void Reloj::SetPLLON(bool e){ // M�todo para activar PLL
 if(e){
  RCC->CR |= RCC_CR_PLLON;
  while(!(RCC->CR&RCC_CR_PLLRDY));
 }
 else
  RCC->CR &= ~RCC_CR_PLLON;
}

void Reloj::SetPLLM(unsigned char m){ // M�todo para configurar PLLM 
 RCC->PLLCFGR &= ~0x3F;
 RCC->PLLCFGR |= (m&0x3F);
}
 
void Reloj::SetPLLN(unsigned short n){ // M�todo para configurar PLLN 
 RCC->PLLCFGR &= ~(0x1FF<<RCC_PLLCFGR_PLLN_Pos);
 RCC->PLLCFGR |= ((n&0x1FF)<<RCC_PLLCFGR_PLLN_Pos); 
}
 
void Reloj::SetPLLP(unsigned char p){ // M�todo para configurar PLLP
 unsigned char pp;  
 RCC->PLLCFGR &= ~(0x3<<RCC_PLLCFGR_PLLP_Pos);
 switch(p){
  case 4: pp=1; break;
  case 6: pp=2; break;
  case 8: pp=3; break;
  default: return;   
 }  
 RCC->PLLCFGR |= ((pp&0x03)<<RCC_PLLCFGR_PLLP_Pos); 
}
 
void Reloj::SetPLLSRC(unsigned char src){ // M�todo para activar fuente del PLL 
 RCC->PLLCFGR &= ~(0x1<<RCC_PLLCFGR_PLLSRC_Pos);
 RCC->PLLCFGR |= ((src&0x1)<<RCC_PLLCFGR_PLLSRC_Pos);       
}   
 
void Reloj::SetSW(unsigned char sw){ // M�todo para configurar fuente de reloj
 RCC->CFGR &= ~0x3;
 RCC->CFGR |= (sw&0x3); 
}
 
void Reloj::SetHPRE(unsigned short h){ // M�todo para configurar HPRE
 unsigned char hh;  
 RCC->CFGR &= ~(0xF<<RCC_CFGR_HPRE_Pos);
 switch(h){
  case 2: hh=8; break;
  case 4: hh=9; break;
  case 8: hh=10; break;
  case 16: hh=11; break;
  case 64: hh=12; break;
  case 128: hh=13; break;
  case 256: hh=14; break;
  case 512: hh=15; break;
  default: return;   
 }   
 RCC->CFGR |= (hh&0xF)<<RCC_CFGR_HPRE_Pos;  
}
 

void Reloj::SetPPRE1(unsigned char p){ // M�todo para configurar PPRE1
 unsigned char pp;      
 RCC->CFGR &= ~(0x7<<RCC_CFGR_PPRE1_Pos);
 switch(p){
  case 2: pp=4; break;
  case 4: pp=5; break;
  case 8: pp=6; break;
  case 16: pp=7; break;
  default: return;   
 }  
 RCC->CFGR |= (pp&0x7)<<RCC_CFGR_PPRE1_Pos; 
}
 
void Reloj::SetPPRE2(unsigned char p){ // M�todo para configurar PPRE2
 unsigned char pp;      
 RCC->CFGR &= ~(0x7<<RCC_CFGR_PPRE2_Pos);
 switch(p){
  case 2: pp=4; break;
  case 4: pp=5; break;
  case 8: pp=6; break;
  case 16: pp=7; break;
  default: return;   
 }  
 RCC->CFGR |= (pp&0x7)<<RCC_CFGR_PPRE2_Pos; 
}
 
unsigned int Reloj::GetHCLK(void){ // M�todo para leer HCLK
 SystemCoreClockUpdate();
 return (unsigned int)SystemCoreClock;  
}
 
unsigned int Reloj::GetPCLK1(void){ // M�todo para leer PCLK1
 unsigned int h=GetHCLK();
 switch((RCC->CFGR>>RCC_CFGR_PPRE1_Pos)&7){
  case 4: h/=2.0;  break;
  case 5: h/=4.0;  break;
  case 6: h/=8.0;  break;
  case 7: h/=16.0; break;
  default:break;
 }
 return h;  
}
    
unsigned int Reloj::GetPCLK2(void){ // M�todo para leer PCLK2
 unsigned int h=GetHCLK();
 switch((RCC->CFGR>>RCC_CFGR_PPRE2_Pos)&7){
  case 4: h/=2.0;  break;
  case 5: h/=4.0;  break;
  case 6: h/=8.0;  break;
  case 7: h/=16.0; break;
  default:break;
 }
 return h;  
}
 
unsigned int Reloj::SetReloj(bool ie,int f){ // M�todo para configurar reloj  
 double FOK,Fclk,Fp,Fn,Fm,Fr,E,Er=250000000;
 unsigned short HPRE_OK,PLLN_OK;    
 unsigned char PPRE_OK,PLLM_OK,PLLP_OK;
 int mi,mf;     
 SetSW(0);
 SetPLLON(0);
 SetHSEON(0);
 SetPLLSRC(0);  
 SetPPRE1(1);   
 SetPPRE2(1);
 SetHPRE(1);
 if(ie){ // Selecci�n reloj interno o externo
  mi=4;mf=8;
  SetHSEON(1);
  SetPLLSRC(1);
  SetSW(1);  
 }
 else{
  mi=8;mf=16;
 }
 Fclk=(double)GetHCLK();
 
 if(f<24000000){
  for(int p=0;p<9;p++){
   Fr=Fclk/HPREFac[p];
   E=fabs(Fr-f);
   if(E<Er){
    Er=E;
    HPRE_OK=(unsigned char)HPREFac[p];
   }
  }
  SetHPRE(HPRE_OK);
 }
 else{
  for(int m=mi;m<=mf;m++){
   Fm=Fclk/(double)m;
   for(int n=2;n<=432;n++){
    Fn=Fm*n;
    if((Fn>=100000000.0)&&(Fn<=432000000.0))
     for(int p=0;p<4;p++){
      Fp=Fn/PLLPFac[p];
      if(Fp>=24000000.0)
       for(int h=0;h<9;h++){
        Fr = Fp/HPREFac[h];
        E=fabs(Fr-f);
        if(E<Er){
         Er=E;
         FOK=Fr;
         HPRE_OK=(unsigned short)HPREFac[h];
         PLLP_OK=(unsigned char)PLLPFac[p];
         PLLN_OK=(unsigned short)n;
         PLLM_OK=(unsigned char)m;
         if(Er==0.0)goto FIN;
        }
       }
     }
    } 
  }
  FIN:
#if defined (STM32F401xE)
  for(int p=4;p>=0;p--){
   if( FOK/PPREFac[p]>42000000.0 )break;
   PPRE_OK=(unsigned char)PPREFac[p];
  }
  SetPPRE1(PPRE_OK);    
#endif
#if defined(STM32F746xx)
  for(int p=4;p>=0;p--){
   if( FOK/PPREFac[p]>54000000.0 )break;
   PPRE_OK = (unsigned char)PPREFac[p];
  }
  SetPPRE1(PPRE_OK);
  for(int p=4;p>=0;p--){
   if( FOK/PPREFac[p]>108000000.0 )break;
   PPRE_OK = (unsigned char)PPREFac[p];
  }
  SetPPRE2(PPRE_OK);
#endif  
  SetPLLM(PLLM_OK);
  SetPLLN(PLLN_OK);
  SetPLLP(PLLP_OK);
  SetHPRE(HPRE_OK);
  SetPLLON(1);
  FLASH->ACR=5UL;
  SetSW(2);
 }
 return GetHCLK();
}
 
unsigned int Reloj::SetRelojHSI(int f){ // M�todo para configurar reloj HSI
 return SetReloj(false,f);
}
 
unsigned int Reloj::SetRelojHSE(int f){ // M�todo para configurar reloj HSE
 return SetReloj(true,f);   
}


