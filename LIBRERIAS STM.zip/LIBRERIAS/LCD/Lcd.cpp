// C�digo Ejemplo 10 5 // 
// Archivo *.cpp //
#include "Lcd.h"
Lcd::Lcd(){Cur=0x0F;} // Constructor
 // Inicia Lcd en Bus de 8 bits   
void Lcd::Iniciar(  
 unsigned char rs,unsigned char e, 
 unsigned char d0,unsigned char d1,unsigned char d2,unsigned char d3,   
 unsigned char d4,unsigned char d5,unsigned char d6,unsigned char d7)
{
 Bus=true; // Bus en 8 bits
  // Se configuran pines de salida    
 RS>>rs; 
 E>>e;   
 D0>>d0; 
 D1>>d1; 
 D2>>d2; 
 D3>>d3; 
 D4>>d4; 
 D5>>d5; 
 D6>>d6; 
 D7>>d7; 
 IniciarDelay(); // Se inicia el servicio de los retardos
 Delay_ms(40); // Retardo de 40m Segundos
 Instruccion(0x30); // Instrucci�n Set bus 8 bits 
 Delay_ms(5); // Retardo de 5m Segundos
 Instruccion(0x30); // Instrucci�n Set bus 8 bits 
 Delay_ms(5); // Retardo de 5m Segundos
 Instruccion(0x30); // Instrucci�n Set bus 8 bits 
 Delay_ms(5); // Retardo de 5m Segundos   
 Instruccion(0x38); // Set Bus 8 bits, doble l�nea y fuente 
 Instruccion(0x06); // Set corrimiento de cursor 
 Instruccion(0x0F); // Set Display ON, cursor y parpadeo ON
 Instruccion(0x01); // Borra display y posiciona en 0
 Delay_ms(3); // Retardo de 3m Segundos
}
 
void Lcd::Iniciar(  
 unsigned char rs,unsigned char e, 
 unsigned char d4,unsigned char d5,unsigned char d6,unsigned char d7)
{
 Bus=false; // Bus en 4 bits
 RS>>rs; // Se configuran pines de salida
 E>>e;  
 D4>>d4; 
 D5>>d5; 
 D6>>d6; 
 D7>>d7;
 IniciarDelay(); // Se inicia el servicio de los retardos
 Delay_ms(40); // Retardo de 40m Segundos
 SetBus(0x03); // Instrucci�n Set bus 4 bits
 Delay_ms(5); // Retardo de 3m Segundos   
 SetBus(0x03); // Instrucci�n Set bus 4 bits
 Delay_ms(5); // Retardo de 3m Segundos       
 Instruccion(0x32); // Instrucci�n Set bus 4 bits
 Instruccion(0x28); // Set Bus 4 bits, doble l�nea y fuente 
 Instruccion(0x06); // Set corrimiento de cursor 
 Instruccion(0x0F); // Set Display ON, cursor y parpadeo ON
 Instruccion(0x01); // Borra display y posiciona en 0
 Delay_ms(3); // Retardo de 40m Segundos
}
 
void Lcd::Clear(void) // M�todo para borrar Lcd
{
 Instruccion(0x01); // Instrucci�n Borra Lcd
 Delay_ms(2); // Retardo de 2m Segundos   
}
 
 
void Lcd::Home(void) // M�todo para posicionar en direcci�n 0
{
 Instruccion(0x02); // Instrucci�n posiciona en 0
 Delay_ms(2); // Retardo de 2m Segundos
}
 
void Lcd::SetBus(unsigned char d) // M�todo para Set en bus de datos
{
 if(Bus) // Eval�a si est� en 4 o 8 bits
 {
  D0=d&1; // Set de los bits del bus en 8 bits
  D1=d&2;
  D2=d&4; D3=d&8;
  D4=d&16; D5=d&32;
  D6=d&64; D7=d&128;
 }
 else
 {
  D4=d&1; // Set de los bits de bus en 4 bits
  D5=d&2;
  D6=d&4; D7=d&8;
 }  
 E=true; // Pulso de Enabled
 Delay_us(5); // Retardo de 5u Segundos
 E=false; // Apaga pulso
 Delay_us(46); // Retardo de 5u Segundos 
}
 
void Lcd::Instruccion(unsigned char i) // M�todo para enviar una instrucci�n
{
 RS=false; // Activa RS en 0 para instrucciones   
 if(Bus)SetBus(i); // Set bus en 8 bits
 else
 {
  SetBus(i>>4); // Set bus en 4 bits D7@D4
  SetBus(i); // Set bus en 4 bits D3@D0    
 }
}   
 
void Lcd::Dato(unsigned char d) // M�todo para enviar un dato 
{
 RS=true; // Activa RS en 1 para datos
 if(Bus)SetBus(d); // Set bus en 8 bits
 else
 {
  SetBus(d>>4); // Set bus en 4 bits D7@D4
  SetBus(d); // Set bus en 4 bits D3@D0    
 }  
}   
 
void Lcd::DireccionDD(unsigned char d) // M�todo para direccionar memoria de datos
{
  // Instrucci�n para Set Direcci�n   
 Instruccion(0x80|(d&0x7F));
}
 
 // M�todo para direccionar memoria generadora de caracteres
void Lcd::DireccionCG(unsigned char d)
{
  // Instrucci�n para Set Direcci�n   
 Instruccion(0x40|(d&0x3F));
}
 
void Lcd::CursorOnOff(bool e) // M�todo para On/Off del Cursor
{
  // Enciende o apaga cursos  
 if(e)Cur|=2; else Cur&=0xFD;   
 Instruccion(Cur); // Aplica instrucci�n      
}
 
 // M�todo para On/Off del parpadeo en cursor
void Lcd::CursorBlink(bool e)
{
  // Enciende o apaga parpadeo    
 if(e)Cur|=1; else Cur&=0xFE;   
 Instruccion(Cur); // Aplica instrucci�n  
}
 
 // M�todo para imprimir un texto
void Lcd::Print(const char *t)
{
 unsigned char n=0; // Contador n
  // Bucle para imprimir hasta encontrar el car�cter Nulo     
 while(t[n]!=0)Dato(t[n++]);
}
 
 // M�todo para imprimir un texto en una l�nea
void Lcd::Print(unsigned char l,const char *t)
{
 switch(l) // Indicador de l�nea
 {
  case 1: DireccionDD(0x40); break;  // L�nea 1
  case 2: DireccionDD(0x14); break;  // L�nea 2
  case 3: DireccionDD(0x54); break;  // L�nea 3
  default:DireccionDD(0x00); break;  // L�nea 0 
 }
 Print(t); // Impresi�n del texto
}
