// C�digo Ejemplo 10 4 // 
// Archivo *.h //   
#ifndef _LCD_H
#define _LCD_H
#include "Pines.h"
#include "Delay.h"
// *** Clase Lcd *** //
class Lcd
{
private:
  // Variables internas   
 unsigned char Cur;  
 bool Bus;
 Pines RS,E,D0,D1,D2,D3,D4,D5,D6,D7;
  // M�todo para Set en bus de datos
 void SetBus(unsigned char d);
public:
 Lcd();
  // Inicia Lcd en Bus de 8 bits
 void Iniciar(  
 unsigned char rs,unsigned char e, 
 unsigned char d0,unsigned char d1,unsigned char d2,unsigned char d3,   
 unsigned char d4,unsigned char d5,unsigned char d6,unsigned char d7);
  // Inicia Lcd en Bus de 4 bits
 void Iniciar(  
 unsigned char rs,unsigned char e,     
 unsigned char d4,unsigned char d5,unsigned char d6,unsigned char d7);
 void Clear(void); // M�todo para borrar Lcd
 void Home(void); // M�todo para posicionar en direcci�n 0
  // M�todo para direccionar memoria de datos
 void DireccionDD(unsigned char d); 
  // M�todo para direccionar memoria generadora de caracteres
 void DireccionCG(unsigned char d);
 void CursorOnOff(bool e); // M�todo para On/Off del Cursor
 void CursorBlink(bool e); // M�todo para On/Off del parpadeo en cursor
 void Dato(unsigned char d); // M�todo para enviar un dato 
 void Instruccion(unsigned char i); // M�todo para enviar una instrucci�n
 void Print(const char *t); // M�todo para imprimir un texto
  // M�todo para imprimir un texto en una l�nea
 void Print(unsigned char l,const char *t); 
};  
#endif




