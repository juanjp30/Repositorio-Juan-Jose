// C�digo Ejemplo 15 6 // 
// Archivo *.cpp //
#include "Spi.h"

Spi::Spi(){}
 // M�todo de inicio puerto SPI
void Spi::Iniciar(void){Iniciar(4000000);}
void Spi::Iniciar(unsigned int vel){Iniciar(SPI_MOSI,SPI_MISO,SPI_CLK,vel);}
void Spi::Iniciar(unsigned char mosi,unsigned char miso,
                  unsigned char clk,unsigned int vel){
 Iniciar(mosi,miso,clk,vel,0,0);}
void Spi::Iniciar(unsigned char mosi,unsigned char miso,unsigned char clk,
                  unsigned int vel,bool cp,bool cf){
  // Variables de trabajo y calculo
 unsigned int Fclk=1;
 unsigned char FunAlt=5; // Funci�n alternativa No 5
 unsigned char BR=7; // Velocidad 
 switch(mosi){ // Evaluaci�n del pin MOSI 
  case PA7:
  case PB5:
   port=SPI1; // Asignaci�n de puerto 1
   RCC->APB2ENR|=RCC_APB2ENR_SPI1EN; // Activaci�n del SPI1 en APB2
   Fclk=PCLK2(); // Captura de reloj APB2
  break;
  case PB15:
  case PC3: 
   port=SPI2; // Asignaci�n de puerto 2
   RCC->APB1ENR|=RCC_APB1ENR_SPI2EN; // Activaci�n del SPI2 en APB1
   Fclk=PCLK1(); // Captura de reloj APB1
  break;
  case PB2:
  case PC12:
  case PD6: FunAlt=6; // Funci�n alternativa No 6  
   port=SPI3; // Asignaci�n de puerto 3
   RCC->APB1ENR|=RCC_APB1ENR_SPI3EN; // Activaci�n del SPI3 en APB1 
   Fclk=PCLK1(); // Captura de reloj APB1
  break;
 
#if defined(STM32F746xx)
  case PE6:
  case PE14:
   port=SPI4; // Asignaci�n de puerto 4
   RCC->APB2ENR|=RCC_APB2ENR_SPI4EN; // Activaci�n del SPI4 en APB2
   Fclk=PCLK2(); // Captura de reloj APB2
  break;
  case PF9:
  case PF11:
   port=SPI5; // Asignaci�n de puerto 5
   RCC->APB2ENR|=RCC_APB2ENR_SPI5EN; // Activaci�n del SPI5 en APB2
   Fclk=PCLK2(); // Captura de reloj APB2
  break;
  case PG14:
   port=SPI6; // Asignaci�n de puerto 6
   RCC->APB2ENR|=RCC_APB2ENR_SPI6EN; // Activaci�n del SPI6 en APB2
   Fclk=PCLK2(); // Captura de reloj APB2
  break;
#endif
 }
 
  // Asignaci�n de pines en modo alternativo SPI
 Miso.FuncionAlternativa(miso,FunAlt);
 Mosi.FuncionAlternativa(mosi,FunAlt);
 Clk.FuncionAlternativa(clk,FunAlt);
 
  // Configuraci�n de puerto
 for(unsigned char x=7;x!=255;x--){ // Calcula velocidad 
  switch(x){
   case 0:if(Fclk/2.0<=vel)BR=0;break;
   case 1:if(Fclk/4.0<=vel)BR=1;break;
   case 2:if(Fclk/8.0<=vel)BR=2;break;
   case 3:if(Fclk/16.0<=vel)BR=3;break;
   case 4:if(Fclk/32.0<=vel)BR=4;break;
   case 5:if(Fclk/64.0<=vel)BR=5;break;
   case 6:if(Fclk/128.0<=vel)BR=6;break;
   case 7:if(Fclk/256.0<=vel)BR=7;break;
  }
 }
 
 port->CR2=0; // Datos en 8 bits F401
#if defined(STM32F746xx)  
 port->CR2=(3UL<<SPI_CR2_DS_Pos); // Datos en 8 bits F746 
#endif
 port->CR1=0;
 port->CR1|=((BR&7)<<SPI_CR1_BR_Pos); // Asignaci�n de velocidad calculada
 port->CR2|=SPI_CR2_SSOE; // Salidas activas
 port->CR1|=SPI_CR1_MSTR; // Activaci�n como maestro
 port->CR1|=SPI_CR1_SPE; // Encendido del modulo
 if(cp)port->CR1|=SPI_CR1_CPOL;
 if(cf)port->CR1|=SPI_CR1_CPHA;
 
 switch(BR){ // Eval�a velocidad configurada
  case 0: Fclk/=2.0;break;
  case 1: Fclk/=4.0;break;
  case 2: Fclk/=8.0;break;
  case 3: Fclk/=16.0;break;
  case 4: Fclk/=32.0;break;
  case 5: Fclk/=64.0;break;
  case 6: Fclk/=128.0;break;
  case 7: Fclk/=256.0;break;
 }
  // Retorna valor de la velocidad configurada
}
 
 // M�todo de transmisi�n y recepci�n serial
unsigned char Spi::TxRxDato(unsigned char tx){
#if defined (STM32F401xE)   
 port->DR=tx; // Transmisi�n del dato
 while(!(port->SR&SPI_SR_TXE)); // Espera fin de la transmisi�n
 while(port->SR&SPI_SR_BSY); // Espera   puerto disponible
 return (unsigned char)port->DR; // Retorna valor recibido en el puerto   
#endif
#if defined(STM32F746xx)    
 unsigned short RXTX=(tx<<8|tx>>4); // Empaquetado de byte    
 port->DR=RXTX; // Transmisi�n del dato
 while(!(port->SR&SPI_SR_TXE)); // Espera fin de la transmisi�n
 while(port->SR&SPI_SR_BSY); // Espera   puerto disponible
 RXTX=port->DR; // Lee bufer
  // Retorna valor recibido y desempaquetado
 return (unsigned char)((RXTX<<4)&0xF0|(RXTX>>8)&0x0F);
#endif 
}
 
 // Operador igualdad para transmitir
unsigned char Spi::operator = (unsigned char tx){
 TxRxDato(tx); // Transmite dato
 return tx; // Retorna igualdad   
}
 
 // Operador get unsigned char para recibir
Spi::operator unsigned char(){
  // Transmite 0 y retorna valor le�do
 return TxRxDato(0);
}

