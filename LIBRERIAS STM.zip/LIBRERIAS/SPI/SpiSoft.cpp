#include "SpiSoft.h"

SpiSoft::SpiSoft(){ClkPol=false;ClkFas=false;}
//M�todo de inicio puerto SPI
void SpiSoft::Iniciar(void){Iniciar(4000000);}
void SpiSoft::Iniciar(unsigned int vel){Iniciar(SPI_MOSI,SPI_MISO,SPI_CLK,vel);}
void SpiSoft::Iniciar(unsigned char mosi,unsigned char miso,unsigned char clk,unsigned int vel)
{Iniciar(mosi,miso,clk,vel,false,false);}
void SpiSoft::Iniciar(unsigned char mosi,unsigned char miso,unsigned char clk,unsigned int vel,bool cp,bool cf)
{
 ClkPol=cp;
 ClkFas=cf;	
 IniciarDelay();
 v=500000/vel;	
 Mosi>>mosi;Mosi=0;
 Miso<<miso;
 Clk>>clk;
 Clk=ClkPol;	
}

unsigned char SpiSoft::TxRxDato(unsigned char tx)
{
 d=0;
 if(!ClkPol)
 {
	if(!ClkFas)
	{
		Mosi=tx&128;Delay_us(v); Clk=1; Delay_us(v); Clk=0; if(Miso==true)d+=128; 
    Mosi=tx&64; Delay_us(v); Clk=1; Delay_us(v); Clk=0; if(Miso==true)d+=64; 
    Mosi=tx&32; Delay_us(v); Clk=1; Delay_us(v); Clk=0; if(Miso==true)d+=32; 
    Mosi=tx&16; Delay_us(v); Clk=1; Delay_us(v); Clk=0; if(Miso==true)d+=16; 
    Mosi=tx&8;  Delay_us(v); Clk=1; Delay_us(v); Clk=0; if(Miso==true)d+=8;
    Mosi=tx&4;  Delay_us(v); Clk=1; Delay_us(v); Clk=0; if(Miso==true)d+=4;
		Mosi=tx&2;  Delay_us(v); Clk=1; Delay_us(v); Clk=0; if(Miso==true)d+=2;
		Mosi=tx&1;  Delay_us(v); Clk=1; Delay_us(v); Clk=0; if(Miso==true)d+=1; 
	}
  else
  {
		Mosi=tx&128;Delay_us(v); Clk=1; if(Miso==true)d+=128;Delay_us(v); Clk=0;
		Mosi=tx&64; Delay_us(v); Clk=1; if(Miso==true)d+=64; Delay_us(v); Clk=0;
    Mosi=tx&32; Delay_us(v); Clk=1; if(Miso==true)d+=32; Delay_us(v); Clk=0;
    Mosi=tx&16; Delay_us(v); Clk=1; if(Miso==true)d+=16; Delay_us(v); Clk=0;
    Mosi=tx&8;  Delay_us(v); Clk=1; if(Miso==true)d+=8;  Delay_us(v); Clk=0;
    Mosi=tx&4;  Delay_us(v); Clk=1; if(Miso==true)d+=4;  Delay_us(v); Clk=0;
		Mosi=tx&2;  Delay_us(v); Clk=1; if(Miso==true)d+=2;  Delay_us(v); Clk=0;
		Mosi=tx&1;  Delay_us(v); Clk=1; if(Miso==true)d+=1;  Delay_us(v); Clk=0; 
	}		
 }
 else
 {
	if(!ClkFas)
	{
		Mosi=tx&128;Delay_us(v); Clk=0; Delay_us(v); Clk=1; if(Miso==true)d+=128; 
		Mosi=tx&64; Delay_us(v); Clk=0; Delay_us(v); Clk=1; if(Miso==true)d+=64; 
    Mosi=tx&32; Delay_us(v); Clk=0; Delay_us(v); Clk=1; if(Miso==true)d+=32; 
    Mosi=tx&16; Delay_us(v); Clk=0; Delay_us(v); Clk=1; if(Miso==true)d+=16; 
    Mosi=tx&8;  Delay_us(v); Clk=0; Delay_us(v); Clk=1; if(Miso==true)d+=8;
    Mosi=tx&4;  Delay_us(v); Clk=0; Delay_us(v); Clk=1; if(Miso==true)d+=4;
		Mosi=tx&2;  Delay_us(v); Clk=0; Delay_us(v); Clk=1; if(Miso==true)d+=2;
		Mosi=tx&1;  Delay_us(v); Clk=0; Delay_us(v); Clk=1; if(Miso==true)d+=1; 
	}
  else
  {
		Mosi=tx&128;Delay_us(v); Clk=0; if(Miso==true)d+=128;Delay_us(v); Clk=1;
		Mosi=tx&64; Delay_us(v); Clk=0; if(Miso==true)d+=64; Delay_us(v); Clk=1;
    Mosi=tx&32; Delay_us(v); Clk=0; if(Miso==true)d+=32; Delay_us(v); Clk=1;
    Mosi=tx&16; Delay_us(v); Clk=0; if(Miso==true)d+=16; Delay_us(v); Clk=1;
    Mosi=tx&8;  Delay_us(v); Clk=0; if(Miso==true)d+=8;  Delay_us(v); Clk=1;
    Mosi=tx&4;  Delay_us(v); Clk=0; if(Miso==true)d+=4;  Delay_us(v); Clk=1;
		Mosi=tx&2;  Delay_us(v); Clk=0; if(Miso==true)d+=2;  Delay_us(v); Clk=1;
		Mosi=tx&1;  Delay_us(v); Clk=0; if(Miso==true)d+=1;  Delay_us(v); Clk=1; 
	}	 
 }	 
 return d;
}
unsigned char SpiSoft::operator = (unsigned char tx){TxRxDato(tx);return tx;}
SpiSoft::operator unsigned char(){return TxRxDato(0);}