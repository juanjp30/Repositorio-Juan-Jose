// C�digo Ejemplo 15 5 // 
// Archivo *.h //
#ifndef _SPI_H
#define _SPI_H
#include "SpiBus.h"
#include "Pines.h"
#include <math.h>
// *** Clase SPI *** //
class Spi : public SpiBus{
private:    
 SPI_TypeDef * port; // Estructura SPI
 Pines Miso,Mosi,Clk; // Pines SPI
public:
 Spi();
  // M�todo de inicio puerto SPI
 void Iniciar(void);
 void Iniciar(unsigned int vel);
 void Iniciar(unsigned char mosi,unsigned char miso,
              unsigned char clk,unsigned int vel);
 void Iniciar(unsigned char mosi,unsigned char miso,
              unsigned char clk,unsigned int vel,bool cp,bool cf);
  // M�todo de transmisi�n y recepci�n serial
 unsigned char TxRxDato(unsigned char tx);
  // Operador igualdad para transmitir
 unsigned char operator = (unsigned char tx);
  // Operador get unsigned char para recibir
 operator unsigned char();
};
#endif


