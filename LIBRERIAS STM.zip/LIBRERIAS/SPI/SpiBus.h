// C�digo Ejemplo 15 3 // 
// Archivo *.h //
#ifndef _SPIBUS_H
#define _SPIBUS_H
 
// *** Clase SPIBUS *** //
class SpiBus{
private:    
public:
 SpiBus();  
  // M�todo de inicio puerto SPI
 virtual void Iniciar(void);
 virtual void Iniciar(unsigned int vel);
 virtual void Iniciar(unsigned char mosi,unsigned char miso,
                      unsigned char   clk,unsigned int vel);
 virtual void Iniciar(unsigned char mosi,unsigned char miso,
                      unsigned char clk,unsigned int vel,bool cp,bool cf);
  // M�todo de transmisi�n y recepci�n serial
 virtual unsigned char TxRxDato(unsigned char tx);
  // Operador igualdad para transmitir
 virtual unsigned char operator = (unsigned char tx);
  // Operador get unsigned char para recibir
 virtual operator unsigned char();
};  
#endif


