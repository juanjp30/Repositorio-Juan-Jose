#ifndef _SPISOF_H
#define _SPISOF_H

#include "SpiBus.h"
#include "Pines.h"
#include "Delay.h"
// *** Clase SPISoft *** //
class SpiSoft : public SpiBus
{
private:    
 Pines Miso,Mosi,Clk;
 bool ClkPol,ClkFas;
 unsigned int v;
 unsigned char d;
public:
 SpiSoft();	
 //M�todo de inicio puerto SPI
 void Iniciar(void);
 void Iniciar(unsigned int vel);
 void Iniciar(unsigned char mosi,unsigned char miso,unsigned char clk,unsigned int vel);
 void Iniciar(unsigned char mosi,unsigned char miso,unsigned char clk,unsigned int vel,bool cp,bool cf);
 //M�todo de transmisi�n y recepci�n serial
 unsigned char TxRxDato(unsigned char tx);
 //Operador igualdad para transmitir
 unsigned char operator = (unsigned char tx);
 //Operador get unsigned char para recibir
 operator unsigned char();
};  
#endif

