// C�digo Ejemplo 11 2 // 
// Archivo *.h //
#ifndef _ADC_H
#define _ADC_H
#include "Pines.h"
class Adc{
private:
 Pines A;
 unsigned char Canal;
public:
  // M�todo para iniciar de forma regular 
 void IniciarRegular(unsigned char can,unsigned char pin);
  // M�todo para iniciar de forma continua
 void IniciarContinuo(unsigned char can,unsigned char pin);
 unsigned int GetAdc(void);  // M�todo para leer canal
 double GetVol(void); // M�todo para leer el voltaje del canal
 operator int(); // Operador para leer canal en entero
 operator unsigned int(); // Operador para leer canal en entero
 operator double(); // Operador para leer canal en voltaje
};
// Estructura Arduino
int analogRead(unsigned char pin); // M�todo para leer pin
#endif


