// C�digo Ejemplo 11 3 // 
// Archivo *.cpp //
#include "Adc.h"
 // M�todo para iniciar de forma regular      
void Adc::IniciarRegular(unsigned char can,unsigned char pin){
 Canal=can; // Se guarda el canal an�logo
  // Se activa el m�dulo ADC1
 RCC->APB2ENR|=RCC_APB2ENR_ADC1EN;
 ADC->CCR=(3UL<<ADC_CCR_ADCPRE_Pos); // Ajusta ADCCLK=PCLK2/8
 ADC1->CR1=0;
 ADC1->CR2=ADC_CR2_ADON; // Se activa modulo ADC1
 ADC1->SMPR1=0xFFFFFFFF; // Se fija m�ximo tiempo de muestreo
 ADC1->SMPR2=0xFFFFFFFF; // Se fija m�ximo tiempo de muestreo
 ADC1->SQR1=0; // Se fijan todas las secuencias en 0
 ADC1->SQR2=0; // Se fijan todas las secuencias en 0
 ADC1->SQR3=0; // Se fijan todas las secuencias en 0
 ADC1->SQR3=(unsigned int)Canal; // Se selecciona canal a convertir
 A.Analogo(pin); // Se define pin como an�logo    
}
 
// M�todo para iniciar de forma continua
void Adc::IniciarContinuo(unsigned char can,unsigned char pin){
 IniciarRegular(can,pin); // Inicia de forma regular
 ADC1->CR2|=ADC_CR2_CONT; // Se activa modo continuo
 ADC1->CR2|=ADC_CR2_SWSTART; // Se inicia la rutina de conversi�n 
}
 
 // M�todo para leer canal
unsigned int Adc::GetAdc(void){
  // retorna valor si el modo continuo esta activo    
 if(ADC1->CR2&ADC_CR2_CONT)return (unsigned int)ADC1->DR;    
 ADC1->SQR3=(unsigned int)Canal; // Se selecciona canal a convertir   
 ADC1->CR2|=ADC_CR2_SWSTART; // Se inicia la rutina de conversi�n
 while(!(ADC1->SR&ADC_SR_EOC)); // Se espera al fin de la conversi�n
 return (unsigned int)ADC1->DR; // Se retorna el valor convertido
}
 
 // M�todo para leer el voltaje del canal
double Adc::GetVol(void){
 return 3.3*GetAdc()/4095.0;
}
 
 // Operador para leer canal en entero
Adc::operator int(){
 return GetAdc();
}
 
 // Operador para leer canal en entero
Adc::operator unsigned int(){
 return GetAdc();
}
 
 // Operador para leer canal en voltaje
Adc::operator double(){
 return GetVol();
}
 
// Estructura Arduino
int analogRead(unsigned char pin){ // M�todo para leer pin
 Adc A;
#if defined (STM32F401xE)
 switch(pin){
  case AP0: A.IniciarRegular(0,AP0); break;
  case AP1: A.IniciarRegular(1,AP1); break;
  case AP2: A.IniciarRegular(4,AP2); break;
  case AP3: A.IniciarRegular(8,AP3); break;
  case AP4: A.IniciarRegular(11,AP4); break;
  case AP5: A.IniciarRegular(10,AP5); break;
  default : return 0; 
 }
#endif
#if defined(STM32F746xx)
 switch(pin){
  case AP0: A.IniciarRegular(3,AP0); break;
  case AP1: A.IniciarRegular(10,AP1); break;
  case AP2: A.IniciarRegular(13,AP2); break;
  case AP3: A.IniciarRegular(9,AP3); break;
  case AP4: A.IniciarRegular(15,AP4); break;
  case AP5: A.IniciarRegular(8,AP5); break;
  default : return 0; 
 }
#endif
 return A.GetAdc();
}
