// C�digo Ejemplo 14 9 // 
// Archivo *.cpp //
#include "I2cSoft.h"
 
/// **** Clase I2cSoft **** ///
I2cSoft::I2cSoft(){v=100;};
void I2cSoft::Iniciar(unsigned int vel){Iniciar(I2C_SDA,I2C_SCL,vel);}
void I2cSoft::Iniciar(void){Iniciar(400000);}
void I2cSoft::Iniciar(unsigned char sda,unsigned char scl,unsigned int vel){
  v=(500000/vel);
  IniciarDelay();
  SDA.DigitalOut(sda);SDA.OpenDrain();SDA=1;
  SCL.DigitalOut(scl);SCL.OpenDrain();SCL=1;
  Delay_ms(10);
  for(int n=0;n<32;n++){
   SCL=0;Delay_ms(1);
   SCL=1;Delay_ms(1);
  }
  for(int n=0;n<32;n++){Start();Delay_ms(1);Stop();Delay_ms(1);}
}
void I2cSoft::Data(bool e){SDA=e;}
void I2cSoft::Start(void){
 SDA=0;Delay_us(v);
 SCL=0;Delay_us(v);
}
void I2cSoft::Stop(void){
 SCL=1;Delay_us(v);
 SDA=1;Delay_us(v);
}
void I2cSoft::RStart(void){
 SDA=1;Delay_us(v);
 SCL=1;Delay_us(v);
 SDA=0;Delay_us(v);
 SCL=0;Delay_us(v);
}
bool I2cSoft::Start(unsigned char id){
 Start();
 return Tx(id);
}
bool I2cSoft::Start(unsigned char id,unsigned char dir){
 Start();
 if(Tx(id))return true;
 if(Tx(dir))return true;
 return false; 
}
bool I2cSoft::RStart(unsigned char id){
 RStart();
 return Tx(id);
}
bool I2cSoft::TestId(unsigned char id){
 bool e;    
 Start(); 
 e=Tx(id&0xFE); 
 Stop();
 return !e; 
}
bool I2cSoft::Tx(unsigned char d){
 bool ack;
 Data(d&128);SCL=1;Delay_us(v);SCL=0;Delay_us(v);
 Data(d&64);SCL=1; Delay_us(v);SCL=0;Delay_us(v);
 Data(d&32);SCL=1; Delay_us(v);SCL=0;Delay_us(v);
 Data(d&16);SCL=1; Delay_us(v);SCL=0;Delay_us(v);
 Data(d&8);SCL=1;  Delay_us(v);SCL=0;Delay_us(v);
 Data(d&4);SCL=1;  Delay_us(v);SCL=0;Delay_us(v);
 Data(d&2);SCL=1;  Delay_us(v);SCL=0;Delay_us(v);
 Data(d&1);SCL=1;  Delay_us(v);SCL=0;SDA=1;Delay_us(v);
 SCL=1;Delay_us(v);ack=SDA.GetPin();SCL=0;Delay_us(v);SDA=0; 
 return ack;
}

unsigned char I2cSoft::Rx(bool ack){
 unsigned char d=0;
 SDA=1;
 SCL=1;Delay_us(v);if(SDA.GetPin())d+=128;SCL=0;Delay_us(v);
 SCL=1;Delay_us(v);if(SDA.GetPin())d+=64;SCL=0;Delay_us(v);
 SCL=1;Delay_us(v);if(SDA.GetPin())d+=32;SCL=0;Delay_us(v);
 SCL=1;Delay_us(v);if(SDA.GetPin())d+=16;SCL=0;Delay_us(v);
 SCL=1;Delay_us(v);if(SDA.GetPin())d+=8;SCL=0;Delay_us(v);
 SCL=1;Delay_us(v);if(SDA.GetPin())d+=4;SCL=0;Delay_us(v);
 SCL=1;Delay_us(v);if(SDA.GetPin())d+=2;SCL=0;Delay_us(v);
 SCL=1;Delay_us(v);if(SDA.GetPin())d+=1;SCL=0;Delay_us(v);
 SDA=ack;SCL=1;Delay_us(v);SCL=0;Delay_us(v);SDA=0; 
 return d;
}
 
 // M�todo para transmitir una cadena de datos 
void I2cSoft::TxI2C(unsigned char adr,const unsigned char *dat,int n){
 if(Start(adr&0xFE))return;
 for(int j=0;j<n;j++)if(Tx(dat[j]))return;
 Stop();
}
 
 // M�todo para transmitir un dato repetido 
void I2cSoft::TxI2C(unsigned char adr,unsigned char dat,int n){
 if(Start(adr&0xFE))return;
 for(int j=0;j<n;j++)if(Tx(dat))return;
 Stop();
}
 
 // M�todo para transmitir un dato
void I2cSoft::TxI2C(unsigned char adr,unsigned char dat){
 if(Start(adr&0xFE))return;
 if(Tx(dat))return;
 Stop();
}
 
 // M�todo para recibir un dato
unsigned char I2cSoft::RxI2C(unsigned char adr){
 unsigned char d;
 if(Start(adr|0x01))return 0;
 d=Rx(true);
 Stop();
 return d;
}
 
 // M�todo para recibir una cadena de datos
void I2cSoft::RxI2C(unsigned char adr,unsigned char *dat,int n){
 unsigned char d;
 if(Start(adr|0x01))return;
 for(int k=0;k<(n-1);k++)dat[k]=Rx(false);
 dat[n-1]=Rx(true);
 Stop();
}
