// C�digo Ejemplo 14 8 // 
// Archivo *.h //
#ifndef _I2CS_H
#define _I2CS_H
 
#include "I2cBus.h"
#include "Pines.h"
#include "Delay.h"
 
/// **** Clase STM32I2cSoft **** ///
class I2cSoft : public I2cBus{
private:
 Pines SDA,SCL;
 unsigned int v;
 void Data(bool e);
 bool Start(unsigned char id);
 bool Start(unsigned char id,unsigned char dir);
 bool RStart(unsigned char id);
 void Start(void);
 void RStart(void);
 void Stop(void);
 bool Tx(unsigned char d);
 unsigned char Rx(bool ack);
public:
 I2cSoft();
 // M�todos para iniciar el puerto 
 void Iniciar(unsigned char sda,unsigned char scl,unsigned int vel);
 void Iniciar(unsigned int vel);
 void Iniciar(void);
 bool TestId(unsigned char id);
  // M�todo para transmitir una cadena de datos 
 void TxI2C(unsigned char adr,const unsigned char *dat,int n);
  // M�todo para transmitir un dato repetido 
 void TxI2C(unsigned char adr,unsigned char dat,int n);
  // M�todo para transmitir un dato
 void TxI2C(unsigned char adr,unsigned char dat);
  // M�todo para recibir un dato
 unsigned char RxI2C(unsigned char adr);
  // M�todo para recibir una cadena de datos
 void RxI2C(unsigned char adr,unsigned char *dat,int n);
};
 
#endif 
