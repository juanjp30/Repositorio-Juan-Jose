// C�digo Ejemplo 14 4 // 
// Archivo *.cpp //
#include "I2cBus.h"
I2cBus::I2cBus(){}
// M�todos para iniciar el puerto
void I2cBus::Iniciar(unsigned int vel){}
void I2cBus::Iniciar(void){}
void I2cBus::Iniciar(unsigned char sda,unsigned char scl,unsigned int vel){}
bool I2cBus::TestId(unsigned char id){}
// M�todo para transmitir un dato repetido
void I2cBus::TxI2C(unsigned char adr,unsigned char dat,int n){}
// M�todo para transmitir una cadena de datos
void I2cBus::TxI2C(unsigned char adr,const unsigned char *dat,int n){}
void I2cBus::TxI2C(unsigned char adr,unsigned char dat){}
// M�todo para recibir un dato
unsigned char I2cBus::RxI2C(unsigned char adr){}
// M�todo para recibir una cadena de datos
void I2cBus::RxI2C(unsigned char adr,unsigned char *dat,int n){}

