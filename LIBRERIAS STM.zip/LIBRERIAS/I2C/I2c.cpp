// C�digo Ejemplo 14 6 //
// Archivo *.cpp //
#include "I2c.h"
void I2c::Iniciar(unsigned int v){Iniciar(I2C_SDA,I2C_SCL,v);}
void I2c::Iniciar(void){Iniciar(400000);}
 // M�todo para iniciar el puerto
void I2c::Iniciar(unsigned char sda,unsigned char scl,unsigned int v){   
 SCL.OpenDrain();SCL.PullUp();
 SDA.OpenDrain();SDA.PullUp();  
 for(int n=0;n<32;n++){
  SCL=0;
  SCL=1;
 }  
 for(int n=0;n<16;n++){
  SDA=0;
  SCL=0;
  SCL=1;
  SDA=1;
 }
#if defined (STM32F401xE)
 unsigned int ccr; // Variable de calculo 
 switch(sda){ // Evaluaci�n del pin sda para asignar el puerto
  case PB7:
  case PB9:
   port=I2C1; // Asignaci�n puerto I2C1
   RCC->APB1ENR|=RCC_APB1ENR_I2C1EN; // Activaci�n reloj I2C1
   break;
  case PB3: 
   port=I2C2; // Asignaci�n puerto I2C2
   RCC->APB1ENR|=RCC_APB1ENR_I2C2EN; // Activaci�n reloj I2C2  
   break;
  case PB4:
  case PC9:
   port=I2C3; // Asignaci�n puerto I2C3
   RCC->APB1ENR|=RCC_APB1ENR_I2C3EN; // Activaci�n reloj I2C3
   break;
  default: return;
 }  
 port->CR1|=I2C_CR1_SWRST; // Reset del I2C
 port->CR1&=~I2C_CR1_SWRST;
 port->FLTR=16; // Apaga filtro an�logo
 port->CR2|=((unsigned char)(PCLK1()/1000000))&0x3F; // Calculo del FREQ 
 port->CCR=0;
 ccr=(unsigned int)(PCLK1()/(2.0*v)); // Calculo del CCR
 if(ccr<4)ccr=4; // M�nimo permitido en modo Sm
 port->CCR|=ccr; // Asignaci�n del CCR
 port->TRISE=(unsigned char)(PCLK1()/1000000)+1; // Calculo del TRISE 1us
 port->CR1|=I2C_CR1_PE; // Activaci�n del I2C
  // Define pin SDA y SCL en funci�n alternativa 4
 SCL.FuncionAlternativa(scl,4);SCL.OpenDrain();SCL.PullUp();
 SDA.FuncionAlternativa(sda,4);SDA.OpenDrain();SDA.PullUp();
#endif 
    
#if defined(STM32F746xx)
switch(sda){ // Evaluaci�n del pin sda para asignar el puerto
 case PB9:
  port=I2C1; // Asignaci�n puerto I2C1
  RCC->APB1ENR|=RCC_APB1ENR_I2C1EN; // Activaci�n reloj I2C1
  RCC->DCKCFGR2&=~(3UL<<RCC_DCKCFGR2_I2C1SEL_Pos);
  RCC->DCKCFGR2|=(2UL<<RCC_DCKCFGR2_I2C1SEL_Pos);
  break;
 case PF0:
 case PB11:
  port=I2C2; // Asignaci�n puerto I2C2
  RCC->APB1ENR|=RCC_APB1ENR_I2C2EN; // Activaci�n reloj I2C2 
  RCC->DCKCFGR2&=~(3UL<<RCC_DCKCFGR2_I2C2SEL_Pos);
  RCC->DCKCFGR2|=(2UL<<RCC_DCKCFGR2_I2C2SEL_Pos);        
  break;
 case PC9:
  port=I2C3; // Asignaci�n puerto I2C3
  RCC->APB1ENR|=RCC_APB1ENR_I2C3EN; // Activaci�n reloj I2C3
  RCC->DCKCFGR2&=~(3UL<<RCC_DCKCFGR2_I2C3SEL_Pos);
  RCC->DCKCFGR2|=(2UL<<RCC_DCKCFGR2_I2C3SEL_Pos);
  break;
 case PD13:
 case PF15:
  port=I2C4; // Asignaci�n puerto I2C4
  RCC->APB1ENR|=RCC_APB1ENR_I2C4EN; // Activaci�n reloj I2C4
  RCC->DCKCFGR2&=~(3UL<<RCC_DCKCFGR2_I2C4SEL_Pos);
  RCC->DCKCFGR2|=(2UL<<RCC_DCKCFGR2_I2C4SEL_Pos);
  break;
 default: return;
 }
 
 // Define pin SDA y SCL en funci�n alternativa 4
 SCL.FuncionAlternativa(scl,4);SCL.OpenDrain();SCL.PullUp();
 SDA.FuncionAlternativa(sda,4);SDA.OpenDrain();SDA.PullUp();
  // Variables de trabajo
 double error=999999;
 double Fscl,Fclk1;
 unsigned char PRESC,SCLhl;
 Fclk1=PCLK1();
 for(unsigned int S=0;S<=255;S++) // Bucle de b�squeda
  for(unsigned char P=0;P<=15;P++){
    // Se calculan todos los posibles valores de Fscl
   Fscl=Fclk1/((2.0*P+1.0)*(S+1.0)+30);
   if(fabs(Fscl-(double)v)<error){ // Se guarda la mejor soluci�n
    error=fabs(Fscl-(double)v);
    PRESC=P;
    SCLhl=(unsigned char)S;
   }
  }
  // Se asignan los tiempos al m�dulo I2C
 port->CR1=0;
 port->CR2=0;   
 port->CR1|=I2C_CR1_ANFOFF; // Apaga filtro an�logo
 port->TIMINGR=0;
 port->TIMINGR|=(PRESC<<I2C_TIMINGR_PRESC_Pos);
 port->TIMINGR|=SCLhl;
 port->TIMINGR|=(SCLhl<<I2C_TIMINGR_SCLH_Pos);
 port->CR1|=I2C_CR1_PE; // Activaci�n del I2C
#endif
}
 
 // M�todo para transmitir un dato repetido
void I2c::TxI2C(unsigned char adr,unsigned char dat,int n){
#if defined (STM32F401xE)
 port->CR1|=I2C_CR1_ACK; // Activa ACK
 port->CR1|=I2C_CR1_START; // Genera START
 while(!(port->SR1&I2C_SR1_SB)); // Espera fin del START
 Dummy=port->SR1; // Limpia banderas
 port->DR=adr&0xFE; // Transmite direcci�n del esclavo
 while(!(port->SR1&I2C_SR1_ADDR)); // Espera trasmisi�n
 Dummy=port->SR1; // Limpia banderas
 Dummy=port->SR2;
 for(int k=0;k<n;k++){ // Transmite n Bytes
  while(!(port->SR1&I2C_SR1_TXE));
  port->DR=dat;  
  while(!(port->SR1&I2C_SR1_BTF));
 }
 port->CR1|=I2C_CR1_STOP; // Genera STOP
 while((port->SR2&I2C_SR2_BUSY)); // Espera bus libre
#endif
 
#if defined(STM32F746xx)
 port->CR2=0; // Reset comandos
 port->CR2|=(((unsigned int)n)<<I2C_CR2_NBYTES_Pos);
 port->CR2|=(adr&0xFE);
 port->CR2|=I2C_CR2_START; // Genera START
 while(!(port->ISR&I2C_ISR_TXE)); // Espera transmisi�n de dato
 for(int k=0;k<n;k++){ // Bucle para transmitir n datos
  port->TXDR=dat; // Transmite dato
  while(!(port->ISR&I2C_ISR_TXE)); // Espera transmisi�n de dato
 }
 port->CR2|=I2C_CR2_STOP; // Genera START
 while(!(port->ISR&I2C_ISR_STOPF )); // Espera fin del STOP
 port->ICR|=I2C_ICR_STOPCF; // Limpia bandera STOP
#endif
}
 
 // M�todo para transmitir una cadena de datos
void I2c::TxI2C(unsigned char adr,const unsigned char *dat,int n){
#if defined (STM32F401xE)
 port->CR1|=I2C_CR1_ACK; // Activa ACK
 port->CR1|=I2C_CR1_START; // Genera START
 while(!(port->SR1&I2C_SR1_SB)); // Espera fin del START
 Dummy=port->SR1; // Limpia banderas
 port->DR=adr&0xFE; // Transmite direcci�n del esclavo
 while(!(port->SR1&I2C_SR1_ADDR)); // Espera trasmisi�n
 Dummy=port->SR1; // Limpia banderas
 Dummy=port->SR2;
 for(int k=0;k<n;k++){ // Transmite n Bytes
  while(!(port->SR1&I2C_SR1_TXE));
  port->DR=dat[k];  
  while(!(port->SR1&I2C_SR1_BTF));
 }
 port->CR1|=I2C_CR1_STOP; // Genera STOP
 while((port->SR2&I2C_SR2_BUSY)); // Espera bus libre
#endif
#if defined(STM32F746xx)
 port->CR2=0; // Reset comandos
 port->CR2|=(((unsigned int)n)<<I2C_CR2_NBYTES_Pos);
 port->CR2|=(adr&0xFE);
 port->CR2|=I2C_CR2_START; // Genera START
 while(!(port->ISR&I2C_ISR_TXE)); // Espera transmisi�n de dato
 for(int k=0;k<n;k++){ // Bucle para transmitir n datos
  port->TXDR=dat[k]; // Transmite dato
  while(!(port->ISR&I2C_ISR_TXE)); // Espera transmisi�n de dato
 }
 port->CR2|=I2C_CR2_STOP; // Genera START
 while(!(port->ISR&I2C_ISR_STOPF )); // Espera fin del STOP
 port->ICR|=I2C_ICR_STOPCF; // Limpia bandera STOP
#endif
}
 
bool I2c::TestId(unsigned char id){
 unsigned int d;
 bool Ok;   
 Ok=false;
#if defined (STM32F401xE)
 port->SR1=0;
 Dummy=port->SR1; // Limpia banderas
 Dummy=port->SR2;
 port->CR1|=I2C_CR1_ACK; // Activa ACK
 port->CR1|=I2C_CR1_START; // Genera START
 while(!(port->SR1&I2C_SR1_SB)); // Espera fin del START
 Dummy=port->SR1; // Limpia banderas  
 port->DR=id&0xFE; // Transmite direcci�n del esclavo
 while(1){ 
  d=port->SR1;
  if(d&I2C_SR1_ADDR){Ok=true;break;}
  if(d&I2C_SR1_AF){Ok=false;break;}
 }
 Dummy=port->SR1; // Limpia banderas
 Dummy=port->SR2;
 port->CR1|=I2C_CR1_STOP; // Genera STOP
 while((port->SR2&I2C_SR2_BUSY)); // Espera bus libre
#endif
#if defined(STM32F746xx)
 port->ICR|=I2C_ICR_NACKCF; // Limpia bandera NACK
 port->CR2=0; // Reset comandos
 port->CR2|=(1UL<<I2C_CR2_NBYTES_Pos); // Set n�mero de bytes a escribir
 port->CR2|=(((id>>1)&0x7F)<<1); // Set direcci�n del esclavo
 port->CR2|=I2C_CR2_START; // Genera START
 while(!(port->ISR&I2C_ISR_TXE)); // Espera transmisi�n de direcci�n
 port->CR2|=I2C_CR2_STOP; // Genera STOP
 while(!(port->ISR&I2C_ISR_STOPF )); // Espera fin del STOP
 port->ICR|=I2C_ICR_STOPCF; // Limpia bandera STOP
 if(!(port->ISR&I2C_ISR_NACKF))Ok=true;
#endif
 return Ok;
}
 
void I2c::TxI2C(unsigned char adr,unsigned char dat){
#if defined (STM32F401xE)
 port->SR1=0;
 Dummy=port->SR1; // Limpia banderas
 Dummy=port->SR2;
 port->CR1|=I2C_CR1_ACK; // Activa ACK
 port->CR1|=I2C_CR1_START; // Genera START
 while(!(port->SR1&I2C_SR1_SB)); // Espera fin del START
 Dummy=port->SR1; // Limpia banderas  
 port->DR=adr&0xFE; // Transmite direcci�n del esclavo
 while(!(port->SR1&I2C_SR1_ADDR)); // Espera trasmisi�n
 Dummy=port->SR1; // Limpia banderas
 Dummy=port->SR2;
 while(!(port->SR1&I2C_SR1_TXE)); // Espera bus disponible
 port->DR=dat; // Transmite byte
 while(!(port->SR1&I2C_SR1_BTF)); // Espera trasmisi�n
 port->CR1|=I2C_CR1_STOP; // Genera STOP
 while((port->SR2&I2C_SR2_BUSY)); // Espera bus libre
#endif
 
#if defined(STM32F746xx)
 port->CR2=0; // Reset comandos
 port->CR2|=(1UL<<I2C_CR2_NBYTES_Pos); // Set n�mero de bytes a escribir
 port->CR2|=(((adr>>1)&0x7F)<<1); // Set direcci�n del esclavo
 port->CR2|=I2C_CR2_START; // Genera START
 while(!(port->ISR&I2C_ISR_TXE)); // Espera transmisi�n de direcci�n
 port->TXDR=dat; // Transmite dato
 while(!(port->ISR&I2C_ISR_TXE)); // Espera transmisi�n de dato
 port->CR2|=I2C_CR2_STOP; // Genera STOP
 while(!(port->ISR&I2C_ISR_STOPF )); // Espera fin del STOP
 port->ICR|=I2C_ICR_STOPCF; // Limpia bandera STOP
#endif
}
 
 // M�todo para recibir un dato
unsigned char I2c::RxI2C(unsigned char adr){
 unsigned char dat;
#if defined (STM32F401xE)
 port->CR1|=I2C_CR1_ACK; // Activa ACK
 port->CR1|=I2C_CR1_START; // Genera START
 while(!(port->SR1&I2C_SR1_SB)); // Espera fin del START
 Dummy=port->SR1; // Limpia banderas
 port->DR=(adr|1); // Transmite direcci�n del esclavo
 while(!(port->SR1&I2C_SR1_ADDR)); // Espera trasmisi�n
 port->CR1&=~I2C_CR1_ACK; // Activa NO ACK
 Dummy=port->SR1; // Limpia banderas
 Dummy=port->SR2;
 port->CR1|=I2C_CR1_STOP; // Genera STOP
 while(!(port->SR1&I2C_SR1_RXNE)); // Espera dato disponible
 dat=port->DR; // Lee dato
 return dat; // Retorna el dato
#endif
 
#if defined(STM32F746xx)
 port->CR2=0; // Reset comandos
 port->CR2|=(1UL<<I2C_CR2_NBYTES_Pos); // Set n�mero un bytes a leer
 port->CR2|=(((adr>>1)&0x7F)<<1); // Set direcci�n del esclavo
 port->CR2|=I2C_CR2_RD_WRN; // Activa lectura
 port->CR2|=I2C_CR2_AUTOEND; // Activa STOP autom�tico
 port->CR2|=I2C_CR2_START; // Genera START
 while(!(port->ISR&I2C_ISR_RXNE)); // Espera dato disponible
 dat=port->RXDR; // Lee dato
#endif
}
 
 // M�todo para recibir una cadena de datos
void I2c::RxI2C(unsigned char adr,unsigned char *dat,int n){
#if defined (STM32F401xE)
 int i=0,k=n;   
 port->CR1|=I2C_CR1_ACK; // Activa ACK
 port->CR1|=I2C_CR1_START; // Genera START
 while(!(port->SR1&I2C_SR1_SB)); // Espera fin del START
 Dummy=port->SR1; // Limpia banderas
 port->DR=(adr|1); // Transmite direcci�n del esclavo 
 while(!(port->SR1&I2C_SR1_ADDR)); // Espera trasmisi�n
 Dummy=port->SR1; // Limpia banderas
 Dummy=port->SR2;
 while(k>2){ // Buble de n-2 Bytes
  while(!(port->SR1&I2C_SR1_RXNE)); // Espera dato disponible
  dat[i++]=port->DR; // Lee dato
  port->CR1|=I2C_CR1_ACK; // Activa ACK
  k--;
 }
 while(!(port->SR1&I2C_SR1_RXNE)); // Espera dato disponible
 dat[i++]=port->DR; // Lee dato
 port->CR1&=~I2C_CR1_ACK; // Activa NO ACK
 port->CR1|=I2C_CR1_STOP; // Genera STOP
 while(!(port->SR1&I2C_SR1_RXNE)); // Espera dato disponible
 dat[i++]=port->DR; // Lee dato
#endif  

#if defined(STM32F746xx)
 port->CR2=0; // Reset comandos
 port->CR2|=(((adr>>1)&0x7F)<<1); // Set direcci�n esclavo
 port->CR2|=(((unsigned int)n)<<I2C_CR2_NBYTES_Pos); // Set n�mero de bytes a leer
 port->CR2|=I2C_CR2_RD_WRN; // Activa lectura
 port->CR2|=I2C_CR2_AUTOEND; // Activa STOP autom�tico
 port->CR2|=I2C_CR2_START; // Genera START
 for(int k=0;k<n;k++){ // Cuenta n entradas
  while(!(port->ISR&I2C_ISR_RXNE)); // Espera dato disponible
  dat[k]=port->RXDR; // Lee dato
 }
#endif
}


