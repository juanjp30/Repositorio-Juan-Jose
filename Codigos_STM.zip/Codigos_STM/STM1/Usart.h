// C�digo Ejemplo 13 2 //
// Archivo *.h //
#ifndef _USART_H
#define _USART_H
#include "Pines.h"

#define SizeCharRead 35
void limpiarAuxUsart();
void ReadStringFun(unsigned char);
extern  unsigned char ReadUsartString[35];
 //  *** Clase Usart ***  // 

class Usart{
private:
 Pines TX,RX;
 USART_TypeDef *port; // Estructura de USART
 unsigned char prt;
public:
  // M�todo para iniciar puerto serial
 
		//Funciones de retorno de datos
 unsigned char DATO0(void);
 unsigned char DATO1(void);
 unsigned char DATO2(void);
 unsigned char DATO3(void);
 unsigned char DATO4(void);
 unsigned char DATO5(void);
 unsigned char DATO6(void);

// Funcion de conversion
int conversion(int cent,int dec,int uni);
int chrtoint(unsigned char chrt);

 void InitUsart(unsigned char rx,unsigned char tx,unsigned int bps);
 void InitUsartSTlink(int bps);
 void InterruptionUsart(FunInt2 fun); // M�todo para asignar interrupci�n de Rx
 void EnvioTusyJuanjo(int numero);
 void SendDataToUsart(float uno,char t);//Metodo para enviar un dato float
 void SendDataToUsart(float uno,float dos,char t);//Metodo para enviar un dato float
 void SendDataToUsart(float uno,float dos,float tres,char t);//Metodo para enviar un dato float
 void SendDataToUsart(float uno,float dos,float tres,float cuatro, char t);
/*Mapeo de Variable->String*/
/*
char | val
I    | int
D    | float
2    | float 0.2
3    | float 0.3
4    | float 0.4

|
*/
 void TxDato(unsigned char d); // M�todo para transmitir un dato
 bool RxListo(void); // M�todo para verificar si llego un dato
 unsigned char RxDato(void); // M�todo para leer un dato
 unsigned char operator = (unsigned char d); // Operador para enviar dato
 void operator = (char *t); // Operador para enviar cadena de texto
 operator unsigned char(); // Operador para esperar un dato
 void operator = (FunInt2 fun); // Operador para asignar interrupci�n de Rx
 
};
#endif


