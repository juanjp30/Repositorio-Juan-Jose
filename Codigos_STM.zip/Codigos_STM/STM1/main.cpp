#include "stm32f4xx.h"                  // Device header
#include "Pines.h"
#include "Usart.h"
#include "stdio.h"
#include "stdint.h" // Para tipos de datos enteros de ancho fijo
Usart Pc;

// Datos
unsigned char dato0 = ' '; // Pololu o Nema
unsigned char dato1 = ' '; // Numero del motor
unsigned char dato2 = ' '; 
unsigned char dato3 = ' ';
unsigned char dato4 = ' ';
unsigned char dato5 = ' ';
unsigned char dato6 = ' ';

// Valor Motores
	// Pololu
	float Vel_motor1=0;
	float Vel_motor2=0;
  float Vel_motor3=0;
	float Ang_motor1=0;
	float Ang_motor2=0;
  float Ang_motor3=0;
	
	// Nema
		// Velocidades
	float Vel_motor4=0;
	float Vel_motor5=0;
  float Vel_motor6=0;
	float Vel_motor7=0;
	
		// Angulo
	float Ang_motor4=0;
	float Ang_motor5=0;
  float Ang_motor6=0;
	float Ang_motor7=0;
	
	// Auxiliares de la conversion de 3 datos
	int aux1=0;
	int aux2=0;
	int aux3=3;
	
	//Error.... Lo sentimos Duarte es que si no se da�aba :/ att tus y juanjo
	int error = 0;

 int main(void){

	Pc.InitUsartSTlink(921600);
	Pc.InterruptionUsart(ReadStringFun);
	
	while(true){// Inicio While true
	
		// Llenado de datos en las variables del main
	dato0=Pc.DATO0();
	dato1=Pc.DATO1();
	dato2=Pc.DATO2();
	dato3=Pc.DATO3();
	dato4=Pc.DATO4();
	dato5=Pc.DATO5();
	dato6=Pc.DATO6();
		// Fin de llenado de datos
		

			switch(dato0){//Inicio Switch de tipo de motor
				case 'A': // Pololu
					switch(dato1){// Cual pololu
						case 'A': // Pololu 1
								if(dato2=='V'){ // Velocidad
									if(dato3=='E'){ // Escribir 
										
								 Vel_motor1=Pc.conversion(Pc.chrtoint(dato4),Pc.chrtoint(dato5),Pc.chrtoint(dato6));
									}else if(dato3=='L'){ // Leer
										dato3='Z';
									 Pc.EnvioTusyJuanjo(Vel_motor1);
								}}
								else if(dato3=='P'){ // Posicion
									if(dato3=='E'){ // Escribir 
									 Ang_motor1=Pc.conversion(Pc.chrtoint(dato4),Pc.chrtoint(dato5),Pc.chrtoint(dato6));
									}else if(dato3=='L'){ // Leer
										dato3='Z';
									 Pc.EnvioTusyJuanjo(Ang_motor1);}
									
								};
									
							break;
						case 'B':
								
						if(dato2=='V'){ // Velocidad
									if(dato3=='E'){ // Escribir 
									 Vel_motor2=Pc.conversion(Pc.chrtoint(dato4),Pc.chrtoint(dato5),Pc.chrtoint(dato6));
									}else if(dato3=='L'); // Leer
									dato3='Z';
									 Pc.EnvioTusyJuanjo(Vel_motor2);
								}
								else if(dato3=='P'){ // Posicion
									if(dato3=='E'){ // Escribir 
									 Ang_motor2=Pc.conversion(Pc.chrtoint(dato4),Pc.chrtoint(dato5),Pc.chrtoint(dato6));
									}else if(dato3=='L'); // Leer
									dato3='Z';
									 Pc.EnvioTusyJuanjo(Ang_motor2);
									
								};
						
							break;
						case 'C':
								
						if(dato2=='V'){ // Velocidad
									if(dato3=='E'){ // Escribir 
									 Vel_motor3=Pc.conversion(Pc.chrtoint(dato4),Pc.chrtoint(dato5),Pc.chrtoint(dato6));
									}else if(dato3=='L'); // Leer
									dato3='Z';
									 Pc.EnvioTusyJuanjo(Vel_motor3);
								}
								else if(dato3=='P'){ // Posicion
									if(dato3=='E'){ // Escribir 
									 Ang_motor3=Pc.conversion(Pc.chrtoint(dato4),Pc.chrtoint(dato5),Pc.chrtoint(dato6));
									}else if(dato3=='L'); // Leer
									dato3='Z';
									 Pc.EnvioTusyJuanjo(Ang_motor3);
									
								};
						
							break;
						default:
								error = 0;
							break;
					}
				break;
				case 'B': // Nemas
					error = 0;
				break;
				default:
					error = 0;
				break;
			}// Fin Switch tipo de Motor
	 }// Fin While true
}// Fin main