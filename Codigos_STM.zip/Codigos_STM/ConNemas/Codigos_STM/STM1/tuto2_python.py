import serial
import time


# Configurar el puerto serie
puerto_serie = serial.Serial('COM9', 921600)  # Cambia 'COM1' por el puerto que estés utilizando y 9600 por la velocidad adecuada


    # Enviar datos
datos_a_enviar = "HH"
puerto_serie.write(datos_a_enviar.encode())

    # Enviar más datos
datos_a_enviar = "AAVE450"
puerto_serie.write(datos_a_enviar.encode())



