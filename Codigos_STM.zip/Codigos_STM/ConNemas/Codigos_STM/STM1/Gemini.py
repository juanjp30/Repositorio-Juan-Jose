import serial
import time
aux = True
# Puerto serial a usar (reemplazar por el nombre correcto)
puerto_serial = 'COM9'

# Velocidad de baudios (ajustar según el dispositivo conectado)
baudios = 921600
Limpiar = "HH"
LeerDato = "AAVL"

# Abrir el puerto serial
with serial.Serial(puerto_serial, baudios) as ser:
    ser.write(Limpiar.encode())
    ser.write(LeerDato.encode())

    while aux == True:
        # Leer una línea del puerto serial
        linea = ser.read()
        if linea == b'A':
            Texto = ser.readline(3)
            # Imprimir la línea leída
            Texto=Texto.decode()
            print(Texto)
            aux = False

        # Si se recibe una señal de fin de línea, salir del bucle

