#include "stm32f4xx.h"                  // Device header
#include "Pines.h"
#include "Usart.h"
#include "stdio.h"
#include "stdint.h" // Para tipos de datos enteros de ancho fijo
Usart Pc;

// Datos
unsigned char dato0 = ' '; // Pololu o Nema
unsigned char dato1 = ' '; // Numero del motor
unsigned char dato2 = ' '; 
unsigned char dato3 = ' ';
unsigned char dato4 = ' ';
unsigned char dato5 = ' ';
unsigned char dato6 = ' ';

// Valor Motores
	// Pololu
	float Vel_motor1=0;
	float Vel_motor2=0;
  float Vel_motor3=0;
	float Ang_motor1=0;
	float Ang_motor2=0;
  float Ang_motor3=0;
	
	// Nema
		// Velocidades
	float Vel_motor4=0;
	float Vel_motor5=0;
  float Vel_motor6=0;
	float Vel_motor7=0;
	
		// Angulo
	float Ang_motor4=0;
	float Ang_motor5=0;
  float Ang_motor6=0;
	float Ang_motor7=0;
	
	// Auxiliares de la conversion de 3 datos
	int aux1=0;
	int aux2=0;
	int aux3=3;
	
	//Error.... Lo sentimos Duarte es que si no se da�aba :/ att tus y juanjo
	int error = 0;
	
	
char palabra[48]={}, *coma;
int iteracion=0, estado=1,angulo_buffer[8] = {0}, anguloPrev[8] = {0}, angulo[8] = {0}, velocidad[8] = {0}, anguloF[8] = {0}, velocidadF[8] = {0}, cont0 = 0, paro = 0;;
int anguloF0 = 0, anguloF1 = 0, anguloF2 = 0, anguloF3 = 0, anguloF4 = 0, anguloF5 = 0, anguloF6 = 0, anguloF7 = 0, velocidadF0 = 0, velocidadF1 = 0, velocidadF2 = 0, velocidadF3 = 0, velocidadF4 = 0, velocidadF5 = 0, velocidadF6 = 0, velocidadF7 = 0;
double anguloD[8] = {0.0}, velocidadD[8] = {0.0};
void movJunta0(int, int), movJunta1(int, int), movJunta2(int, int), movJunta3(int, int), movJunta4(int, int), movJunta5(int, int), movJunta6(int, int), movJunta7(int, int);


 int main(void){

	Pc.InitUsartSTlink(921600);
	Pc.InterruptionUsart(ReadStringFun);
	 
	RCC->AHB1ENR = 0xFF;
	GPIOA->MODER |= 0XA0;
	GPIOB->MODER |=0x55555555;
	GPIOC->MODER |=0x55555555;

	RCC->APB1ENR = (1UL<<17);
	USART2->BRR= 0X683;
	USART2->CR1 = 0X012C;
	USART2->CR1 |= 0X2000;
	GPIOA->AFR[0] |= 0X7700;
	NVIC_EnableIRQ(USART2_IRQn);
	
	GPIOB->ODR = 0X0000;
	GPIOC->ODR = 0X0000;
	
	while(true){// Inicio While true
	
		// Llenado de datos en las variables del main
	dato0=Pc.DATO0();
	dato1=Pc.DATO1();
	dato2=Pc.DATO2();
	dato3=Pc.DATO3();
	dato4=Pc.DATO4();
	dato5=Pc.DATO5();
	dato6=Pc.DATO6();
		// Fin de llenado de datos
		

			switch(dato0){//Inicio Switch de tipo de motor
				case 'A': // Pololu
					switch(dato1){// Cual pololu
						case 'A': // Pololu 1
								if(dato2=='V'){ // Velocidad
									if(dato3=='E'){ // Escribir 
										
								 Vel_motor1=Pc.conversion(Pc.chrtoint(dato4),Pc.chrtoint(dato5),Pc.chrtoint(dato6));
									}else if(dato3=='L'){ // Leer
										dato3='Z';
									 Pc.EnvioTus(Vel_motor1);
								}}
								else if(dato3=='P'){ // Posicion
									if(dato3=='E'){ // Escribir 
									 Ang_motor1=Pc.conversion(Pc.chrtoint(dato4),Pc.chrtoint(dato5),Pc.chrtoint(dato6));
									}else if(dato3=='L'){ // Leer
										dato3='Z';
									 Pc.EnvioTus(Ang_motor1);}
									
								};
									
							break;
						case 'B':
								
						if(dato2=='V'){ // Velocidad
									if(dato3=='E'){ // Escribir 
									 Vel_motor2=Pc.conversion(Pc.chrtoint(dato4),Pc.chrtoint(dato5),Pc.chrtoint(dato6));
									}else if(dato3=='L'); // Leer
									dato3='Z';
									 Pc.EnvioTus(Vel_motor2);
								}
								else if(dato3=='P'){ // Posicion
									if(dato3=='E'){ // Escribir 
									 Ang_motor2=Pc.conversion(Pc.chrtoint(dato4),Pc.chrtoint(dato5),Pc.chrtoint(dato6));
									}else if(dato3=='L'); // Leer
									dato3='Z';
									 Pc.EnvioTus(Ang_motor2);
									
								};
						
							break;
						case 'C':
								
						if(dato2=='V'){ // Velocidad
									if(dato3=='E'){ // Escribir 
									 Vel_motor3=Pc.conversion(Pc.chrtoint(dato4),Pc.chrtoint(dato5),Pc.chrtoint(dato6));
									}else if(dato3=='L'); // Leer
									dato3='Z';
									 Pc.EnvioTus(Vel_motor3);
								}
								else if(dato3=='P'){ // Posicion
									if(dato3=='E'){ // Escribir 
									 Ang_motor3=Pc.conversion(Pc.chrtoint(dato4),Pc.chrtoint(dato5),Pc.chrtoint(dato6));
									}else if(dato3=='L'); // Leer
									dato3='Z';
									 Pc.EnvioTus(Ang_motor3);
									
								};
						
							break;
						default:
								error = 0;
							break;
					}
				break;
				case 'B': // Nemas
					switch(dato2){
						case 'A':
								if(dato3=='V'){
										Vel_motor4=Pc.conversion(Pc.chrtoint(dato4),Pc.chrtoint(dato5),Pc.chrtoint(dato6));
									}else if(dato3=='P'){
										Ang_motor4=Pc.conversion(Pc.chrtoint(dato4),Pc.chrtoint(dato5),Pc.chrtoint(dato6));
									};
										movJunta0(Ang_motor4,Vel_motor4);
							break;
						case 'B':
							if(dato3=='V'){
										Vel_motor4=Pc.conversion(Pc.chrtoint(dato4),Pc.chrtoint(dato5),Pc.chrtoint(dato6));
									}else if(dato3=='P'){
										Ang_motor4=Pc.conversion(Pc.chrtoint(dato4),Pc.chrtoint(dato5),Pc.chrtoint(dato6));
									};
									movJunta1(Ang_motor4,Vel_motor4);
							break;
						case 'C':
							if(dato3=='V'){
										Vel_motor5=Pc.conversion(Pc.chrtoint(dato4),Pc.chrtoint(dato5),Pc.chrtoint(dato6));
									}else if(dato3=='P'){
										Ang_motor5=Pc.conversion(Pc.chrtoint(dato4),Pc.chrtoint(dato5),Pc.chrtoint(dato6));
									};
									movJunta1(Ang_motor5,Vel_motor5);
							break;
						case 'D':
							if(dato3=='V'){
										Vel_motor6=Pc.conversion(Pc.chrtoint(dato4),Pc.chrtoint(dato5),Pc.chrtoint(dato6));
									}else if(dato3=='P'){
										Ang_motor6=Pc.conversion(Pc.chrtoint(dato4),Pc.chrtoint(dato5),Pc.chrtoint(dato6));
									};
									movJunta1(Ang_motor6,Vel_motor6);
							break;
					}
				break;
				default:
					error = 0;
				break;

			}// Fin Switch tipo de Motor
			
		
	 }// Fin While true
	
// Funciones de Nema
	

}// Fin main
 
void movJunta0(int a, int b)
{
		anguloF0 = a*9;  // *50 PARA NEMA 23
		velocidadF0 = b;
	
		if(anguloF0 < 0)
		{
			anguloF0 = abs(anguloF0);
			GPIOC->ODR |= (1UL << 1);          //DIRECCI?N HORARIA
		}
		else 
		{
			GPIOC->ODR &=~ (1UL << 1);         //DIRECCI?N ANTIHORARIA
		}
		
		for(int i=0;i<anguloF0;i++)
		{
			GPIOC->ODR &=~ (1UL << 2);        //ENABLE
			GPIOC->ODR |= (1UL << 0);         //PULSO ALTO
			for(int i=0;i<velocidadF0;i++){}; //ANCHO DE PULSO
			GPIOC->ODR &=~ (1UL << 0);        //PULSO BAJO
			for(int i=0;i<velocidadF0;i++){}; //ANCHO DE PULSO
		}
			
		//GPIOC->ODR |= (1UL << 2);  //ENABLE
		
		anguloF0 = 0;
		velocidadF0 = 0;		
		paro = 1;
		
}

void movJunta1(int a, int b)
{
		anguloF1 = a*50;
		velocidadF1 = b;
	
		if(anguloF1 < 0)
		{
			anguloF1 = abs(anguloF1);
			GPIOC->ODR |= (1UL << 4);          //DIRECCI?N HORARIA
		}
		else 
		{
			GPIOC->ODR &=~ (1UL << 4);         //DIRECCI?N ANTIHORARIA
		}
		
		for(int i=0;i<anguloF1;i++)
		{
			GPIOC->ODR &=~ (1UL << 5);        //ENABLE
			GPIOC->ODR |= (1UL << 3);         //PULSO ALTO
			for(int i=0;i<velocidadF1;i++){}; //ANCHO DE PULSO
			GPIOC->ODR &=~ (1UL << 3);        //PULSO BAJO
			for(int i=0;i<velocidadF1;i++){}; //ANCHO DE PULSO
		}
			
		//GPIOC->ODR |= (1UL << 5);  //ENABLE
		
		anguloF1 = 0;
		velocidadF1 = 0;
		paro = 1;

		
}


void movJunta2(int a, int b)
{
		anguloF2 = a*100;
		velocidadF2 = b;
	
		if(anguloF2 < 0)
		{
			anguloF2 = abs(anguloF2);
			GPIOC->ODR |= (1UL << 10);          //DIRECCI?N HORARIA
		}
		else 
		{
			GPIOC->ODR &=~ (1UL << 10);         //DIRECCI?N ANTIHORARIA
		}
		
		for(int i=0;i<anguloF2;i++)
		{
			GPIOC->ODR &=~ (1UL << 11);        //ENABLE
			GPIOC->ODR |= (1UL << 9);         //PULSO ALTO
			for(int i=0;i<velocidadF2;i++){}; //ANCHO DE PULSO
			GPIOC->ODR &=~ (1UL << 9);        //PULSO BAJO
			for(int i=0;i<velocidadF2;i++){}; //ANCHO DE PULSO
		}
			
		//GPIOC->ODR |= (1UL << 11);  //ENABLE
		
		anguloF2 = 0;
		velocidadF2 = 0;
		paro = 1;
		
}

void movJunta3(int a, int b)
{
		anguloF3 = a;
		velocidadF3 = b;
	
		if(anguloF3 < 0)
		{
			anguloF3 = abs(anguloF3);
			GPIOC->ODR |= (1UL << 13);          //DIRECCI?N HORARIA
		}
		else 
		{
			GPIOC->ODR &=~ (1UL << 13);         //DIRECCI?N ANTIHORARIA
		}
		
		for(int i=0;i<anguloF3;i++)
		{
			GPIOC->ODR &=~ (1UL << 14);        //ENABLE
			GPIOB->ODR |= (1UL << 15);         //PULSO ALTO
			for(int i=0;i<velocidadF3;i++){}; //ANCHO DE PULSO
			GPIOB->ODR &=~ (1UL << 15);        //PULSO BAJO
			for(int i=0;i<velocidadF3;i++){}; //ANCHO DE PULSO
		}
			
		//GPIOC->ODR |= (1UL << 14);  //ENABLE
		
		anguloF3 = 0;
		velocidadF3 = 0;	
		paro = 1;

}


void movJunta4(int a, int b)
{
		anguloF4 = a;
		velocidadF4 = b;
	
		if(anguloF4 < 0)
		{
			anguloF4 = abs(anguloF4);
			GPIOB->ODR |= (1UL << 1);          //DIRECCI?N HORARIA
		}
		else 
		{
			GPIOB->ODR &=~ (1UL << 1);         //DIRECCI?N ANTIHORARIA
		}
		
		for(int i=0;i<anguloF4;i++)
		{
			GPIOB->ODR &=~ (1UL << 2);        //ENABLE
			GPIOB->ODR |= (1UL << 0);         //PULSO ALTO
			for(int i=0;i<velocidadF4;i++){}; //ANCHO DE PULSO
			GPIOB->ODR &=~ (1UL << 0);        //PULSO BAJO
			for(int i=0;i<velocidadF4;i++){}; //ANCHO DE PULSO
		}
			
		//GPIOB->ODR |= (1UL << 2);  //ENABLE
		
		anguloF4 = 0;
		velocidadF4 = 0;	
		paro = 1;

}