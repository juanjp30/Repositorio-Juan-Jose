#ifndef _I2C_H
#define _I2C_H
#include "Pines.h"
#if defined (STM32F401xE)	||	(STM32F411xE)
#include "stm32f4xx.h"                  // Device header

#endif
#if defined (STM32F767xx) || (STM32F746xx)
#include "stm32f7xx.h"                  // Device header
#endif
class I2c{
	private:
		char adr;
	protected:
		unsigned int Dummy; // Variables de trabajo  
		Pines SDA,SCL; // Pines Datos y Reloj     
		I2C_TypeDef *port; // Estructura I2C
	public:
		/*Metodo para Iniciar I2C*/
		void InitI2c(unsigned char sda, unsigned char scl, unsigned int v);
		/*Metodo para asignar direccion*/
		void SetAdrresI2c( char ADR);
		void WriteI2c( char adrMemory, char data);
		void WriteI2cO( char adrMemory, char data);
		void WriteI2c( char adrMemory, char *data, uint16_t length);
		void WriteI2c(char *data, uint16_t length);
		char ReadI2c( char adrMemory);
};
#endif