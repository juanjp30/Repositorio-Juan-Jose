#include "PuenteH.h".h"
//Timers ocupados  1 3 4 5
/*
*/
void PuenteH::InitShieldMotor(double fre){//frecuencia del PWM
	//Definicion de encoders //Tim 5 y Tim  y Tim 3
	EncoA.IniciarEncoder(5,PA0,PA1); //check
	EncoB.IniciarEncoder(4,PB6,PB7); //check
	EncoC.IniciarEncoder(2,PA15,PB3); // To check
	
	//Definicion de PWM MOTOR A
	
	MotorA.IniciarPwm(3,fre); //Tim 4
	MotorA.PinCanal(PC6);	
	MotorA.ActivarCanal(1);
	MotorA.SetPwm(1,0);
	
	//Definicion de PWM MOTOR B
	
	MotorB.IniciarPwm(3,fre); //Tim 2
	MotorB.PinCanal(PC7);		
	MotorB.ActivarCanal(2);
	MotorB.SetPwm(2,0);
	
	//Definicion de PWM MOTOR C
	
	//MotorC.IniciarPwm(3,fre); //Tim 2
	MotorC.PinCanal(PC8);		
	MotorC.ActivarCanal(3);
	MotorC.SetPwm(3,0);
	
	
	
	
	
	//Motor A    PA6
	//Motor B	   PA5
	
	//Enables de Enables Motor A
	/*
	Tabla 		EnableA_1		EnableA_2
	delante 			1						0
	atras		 			0						1
	  
	*/
	EnableA_1>>PA6;	EnableA_1=0;
	EnableA_2>>PA5;	EnableA_2=0;
	
	EnableB_1>>PA7;	EnableB_1=0;
	EnableB_2>>PA8;	EnableB_2=0;
	
	
}
int PuenteH::GetAbsolutoA(void){
	return EncoA.GetAbsoluto();
	
}
int PuenteH::GetAbsolutoB(void){
	return EncoB.GetAbsoluto();
}
int PuenteH::GetAbsolutoC(void){
	return EncoC.GetAbsoluto();
}


void PuenteH::RestConA(void){
	EncoA.RestCon();
	
}
void PuenteH::RestConB(void){
	EncoB.RestCon();
}
void PuenteH::RestConC(void){
	EncoC.RestCon();
}

void PuenteH::ChangePwmA(float val){
	if(val<0.0){
		val=val*-1;
		EnableA_1=1;	EnableA_2=0;
		
	}else{
		EnableA_1=0;	EnableA_2=1;
		
	}
	MotorA.ActivarCanal(1);
	MotorA.SetPwm(1,val);
	
}
void PuenteH::ChangePwmB(float val){
	if(val<0.0){
		val=val*-1;
		EnableB_1=1;	EnableB_2=0;
	  //EnableB=1;
	}
	else{
		EnableB_1=0;	EnableB_2=1;
		//EnableB=0;
	}
	MotorB.ActivarCanal(2);
	MotorB.SetPwm(2,val);
	
}
void PuenteH::ChangePwmC(float val){
	if(val<0.0){
		val=val*-1;
	  //EnableB=1;
	}
	else{
		//EnableB=0;
	}
	MotorC.ActivarCanal(2);
	MotorC.SetPwm(3,val);
	
}


