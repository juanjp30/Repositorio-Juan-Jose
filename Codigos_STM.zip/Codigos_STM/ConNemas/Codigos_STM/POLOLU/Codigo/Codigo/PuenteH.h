#ifndef _PUENTEH_H
#define _PUENTEH_H
#include "Timer.h"
#include "Encoder.h"
#include "Pines.h"
#include "Pwm.h"
// *** Clase Motor *** //
class PuenteH : public Timer {
private:
  Encoder EncoA, EncoB, EncoC;
  //Definicion de Pwm
  Pwm MotorA, MotorB, MotorC;
	Pines EnableA_1,EnableA_2;
	Pines EnableB_1,EnableB_2;
  int PosEncoder;  // Variable de conteo del Encoder
	float VelIzq = 0.0, VelDer = 0.0;  //RPM
 

public:
  // M�todo para iniciar Motor
  void InitShieldMotor(double fre);
  // M�todos para obtener pulsos Motor
  int GetAbsolutoA(void);
  int GetAbsolutoB(void);
	int GetAbsolutoC(void);
  // M�todos para Resetear pulsos Motor
  void RestConA(void);
  void RestConB(void);
	void RestConC(void);
	// Metodos para Cambiar PWM
  void ChangePwmA(float val);
  void ChangePwmB(float val);
	void ChangePwmC(float val);
//	float ControlM1(float M1, float Velocity);
//	float ControlM2(float M2, float Velocity);
};
#endif