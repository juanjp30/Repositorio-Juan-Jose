// C�digo Ejemplo 16 2 // 
// Archivo *.h //
#ifndef _TIMER_H
#define _TIMER_H
#include "Pines.h"
#include <math.h>
// *** Clase Timer *** //
class Timer{
protected:
 TIM_TypeDef *t; // Estructura Timer
 unsigned char tim; // Numero de Timer
 unsigned long APB1(void); // C�lculo de fuente APB1
 unsigned long APB2(void); // C�lculo de fuente APB2
 unsigned long APB; // Valor de APB
public:
 void InitTimer(unsigned char tmr,double Ft,FunInt fun);
 void SetTimer(unsigned char tmr); // Asigna Timer
 void SetPeriodo(double Tt); // Asigna periodo
 void SetFrecuencia(double Ft); // Asigna frecuencia
 double GetPeriodo(void); // Lee periodo
 double GetFrecuencia(void); // Lee frecuencia
 void Interrpcion(FunInt fun); // Asigna interrupci�n
 double operator = (double Tt); // Asigna periodo
 void operator = (FunInt fun); // Asigna interrupci�n
};
#endif


