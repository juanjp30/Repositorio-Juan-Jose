#include "I2c.h"
void I2c::InitI2c(unsigned char sda, unsigned char scl, unsigned int v){
	SCL.OpenDrain();SCL.PullUp();
	SDA.OpenDrain();SDA.PullUp();  
	for(int n=0;n<32;n++){
		SCL=0;
		SCL=1;
	}  
	for(int n=0;n<16;n++){
		SDA=0;
		SCL=0;
		SCL=1;
		SDA=1;
	}
	#if defined (STM32F401xE)
	 unsigned int ccr; // Variable de calculo 
	 switch(sda){ // Evaluaci?n del pin sda para asignar el puerto
		case PB7:
		port=I2C1; // Asignaci?n puerto I2C1
		 RCC->APB1ENR|=RCC_APB1ENR_I2C1EN; // Activaci?n reloj I2C1
		case PB9:
		 port=I2C1; // Asignaci?n puerto I2C1
		 RCC->APB1ENR|=RCC_APB1ENR_I2C1EN; // Activaci?n reloj I2C1
		 break;
		case PB3: 
		 port=I2C2; // Asignaci?n puerto I2C2
		 RCC->APB1ENR|=RCC_APB1ENR_I2C2EN; // Activaci?n reloj I2C2  
		 break;
		case PB4:
		case PC9:
		 port=I2C3; // Asignaci?n puerto I2C3
		 RCC->APB1ENR|=RCC_APB1ENR_I2C3EN; // Activaci?n reloj I2C3
		 break;
		default: return;
	 }  
	 port->CR1|=I2C_CR1_SWRST; // Reset del I2C
	 port->CR1&=~I2C_CR1_SWRST;
	 port->FLTR=16; // Apaga filtro an?logo
	 port->CR2|=((unsigned char)(PCLK1()/1000000))&0x3F; // Calculo del FREQ 
	 port->CCR=0;
	 ccr=(unsigned int)(PCLK1()/(2.0*v)); // Calculo del CCR
	 if(ccr<4)ccr=4; // M?nimo permitido en modo Sm
	 port->CCR|=ccr; // Asignaci?n del CCR
	 port->TRISE=(unsigned char)(PCLK1()/1000000)+1; // Calculo del TRISE 1us
	 port->CR1|=I2C_CR1_PE; // Activaci?n del I2C
		// Define pin SDA y SCL en funci?n alternativa 4
	 SCL.AlternativeFunction(scl,4);SCL.OpenDrain();SCL.PullUp();
	 SDA.AlternativeFunction(sda,4);SDA.OpenDrain();SDA.PullUp();
	#endif 
			
	#if defined(STM32F746xx) || (STM32F767xx)
	switch(sda){ // Evaluaci?n del pin sda para asignar el puerto
	 case PB7:
		port=I2C1; // Asignaci?n puerto I2C1
		RCC->APB1ENR|=RCC_APB1ENR_I2C1EN; // Activaci?n reloj I2C1
		RCC->DCKCFGR2&=~(3UL<<RCC_DCKCFGR2_I2C1SEL_Pos);
		RCC->DCKCFGR2|=(2UL<<RCC_DCKCFGR2_I2C1SEL_Pos);
	 case PB9:
		port=I2C1; // Asignaci?n puerto I2C1
		RCC->APB1ENR|=RCC_APB1ENR_I2C1EN; // Activaci?n reloj I2C1
		RCC->DCKCFGR2&=~(3UL<<RCC_DCKCFGR2_I2C1SEL_Pos);
		RCC->DCKCFGR2|=(2UL<<RCC_DCKCFGR2_I2C1SEL_Pos);
		break;
	 case PF0:
	 case PB11:
		port=I2C2; // Asignaci?n puerto I2C2
		RCC->APB1ENR|=RCC_APB1ENR_I2C2EN; // Activaci?n reloj I2C2 
		RCC->DCKCFGR2&=~(3UL<<RCC_DCKCFGR2_I2C2SEL_Pos);
		RCC->DCKCFGR2|=(2UL<<RCC_DCKCFGR2_I2C2SEL_Pos);        
		break;
	 case PC9:
		port=I2C3; // Asignaci?n puerto I2C3
		RCC->APB1ENR|=RCC_APB1ENR_I2C3EN; // Activaci?n reloj I2C3
		RCC->DCKCFGR2&=~(3UL<<RCC_DCKCFGR2_I2C3SEL_Pos);
		RCC->DCKCFGR2|=(2UL<<RCC_DCKCFGR2_I2C3SEL_Pos);
		break;
	 case PD13:
	 case PF15:
		port=I2C4; // Asignaci?n puerto I2C4
		RCC->APB1ENR|=RCC_APB1ENR_I2C4EN; // Activaci?n reloj I2C4
		RCC->DCKCFGR2&=~(3UL<<RCC_DCKCFGR2_I2C4SEL_Pos);
		RCC->DCKCFGR2|=(2UL<<RCC_DCKCFGR2_I2C4SEL_Pos);
		break;
	 default: return;
	 }
	 
	 // Define pin SDA y SCL en funci?n alternativa 4
	 SCL.AlternativeFunction(scl,4);SCL.OpenDrain();SCL.PullUp();
	 SDA.AlternativeFunction(sda,4);SDA.OpenDrain();SDA.PullUp();
		// Variables de trabajo
	 double error=999999;
	 double Fscl,Fclk1;
	 unsigned char PRESC,SCLhl;
	 Fclk1=PCLK1();
	 for(unsigned int S=0;S<=255;S++) // Bucle de b?squeda
		for(unsigned char P=0;P<=15;P++){
			// Se calculan todos los posibles valores de Fscl
		 Fscl=Fclk1/((2.0*P+1.0)*(S+1.0)+30);
		 if(fabs(Fscl-(double)v)<error){ // Se guarda la mejor soluci?n
			error=fabs(Fscl-(double)v);
			PRESC=P;
			SCLhl=(unsigned char)S;
		 }
		}
		// Se asignan los tiempos al m?dulo I2C
	 port->CR1=0;
	 port->CR2=0;   
	 port->CR1|=I2C_CR1_ANFOFF; // Apaga filtro an?logo
	 port->TIMINGR=0;
	 port->TIMINGR|=(PRESC<<I2C_TIMINGR_PRESC_Pos);
	 port->TIMINGR|=SCLhl;
	 port->TIMINGR|=(SCLhl<<I2C_TIMINGR_SCLH_Pos);
	 port->CR1|=I2C_CR1_PE; // Activaci?n del I2C
	#endif
}

void I2c::SetAdrresI2c( char ADR){
			adr=ADR;
}
/*Envio de datos una vez con direccion de memoria*/
void I2c::WriteI2c(char adrMemory, char data){
	#if defined (STM32F401xE)	||	(STM32F411xE)
	/*Iniciar*/
	port->CR1 |= (1<<10);  // Enable the ACK
	port->CR1 |= (1<<8);  // Generate START
	while (!(port->SR1 & (1<<0)));  // Wait fror SB bit to set
	/*Envio de direccion*/
	port->DR = adr;  //  send the address
	while (!(port->SR1 & I2C_SR1_ADDR));  // wait for ADDR bit to set
	uint8_t temp = port->SR1 | port->SR2;  // read SR1 and SR2 to clear the ADDR bit
	
	/*Envio de direccion de registro*/
	while (!(port->SR1 & (1<<7)));  // wait for TXE bit to set
	port->DR = adrMemory;
	while (!(port->SR1 & (1<<2)));  // wait for BTF bit to set
	/*Envio de dato*/
	while (!(port->SR1 & (1<<7)));  // wait for TXE bit to set
	port->DR = data;
	while (!(port->SR1 & (1<<2)));  // wait for BTF bit to set
	/*Envi bit de stop*/
	port->CR1 |= I2C_CR1_STOP; //condicion de Stop

#endif
	#if defined (STM32F767xx) || (STM32F746xx)
	uint16_t length=1;
	port->CR2 |=I2C_CR2_AUTOEND;
	port->CR2 &=~I2C_CR2_RD_WRN; 
	port->CR2 |=(adr<<1); 
	port->CR2 |=(2<<16); 
	port->CR2 |=I2C_CR2_START; 
	while(!(port->ISR & I2C_ISR_TXIS));
	port->TXDR =adrMemory;
	while(!(port->ISR & I2C_ISR_TXIS));
	port->TXDR =data; 
	while(!(port->ISR & I2C_ISR_TXE));
	port->CR2|=I2C_CR2_STOP;//Genera STOP		
	while(!(port->ISR & I2C_ISR_STOPF));
	port->CR2 =0x02000000;
	#endif
}
void I2c::WriteI2cO(char adrMemory, char data){
	#if defined (STM32F401xE)	||	(STM32F411xE)
	/*Iniciar*/
	port->CR1 |= I2C_CR1_ACK;  // Enable the ACK
	port->CR1 |= I2C_CR1_START;  // Generate START
	while(!(port->SR1&I2C_SR1_SB)); // Espera fin del START
	Dummy=port->SR1; // Limpia banderas
	/*Envio de direccion*/
	port->DR = adr;  //  send the address
	while (!(port->SR1 & I2C_SR1_ADDR));  // wait for ADDR bit to set
	uint8_t temp = port->SR1 | port->SR2;  // read SR1 and SR2 to clear the ADDR bit
	
	/*Envio de direccion de registro*/
	while (!(port->SR1 & (1<<7)));  // wait for TXE bit to set
	port->DR = adrMemory;
	while (!(port->SR1 & (1<<2)));  // wait for BTF bit to set
	/*Envio de dato*/
	while (!(port->SR1 & (1<<7)));  // wait for TXE bit to set
	port->DR = data;
	while (!(port->SR1 & (1<<2)));  // wait for BTF bit to set
	/*Envi bit de stop*/
	port->CR1 |= I2C_CR1_STOP; //condicion de Stop

#endif
	#if defined (STM32F767xx) || (STM32F746xx)
	uint16_t length=1;
	char send_arr[length+1];
	send_arr[0]=adrMemory;
	for (int i=1;(i<length+1);i++)
		{
		send_arr[i]=data;
		}

	/*Enable I2C*/
	I2C1->CR1 |=I2C_CR1_PE;
	/*Set slave address*/
	I2C1->CR2=(adr<<1);
	/*7-bit addressing*/
	I2C1->CR2&=~I2C_CR2_ADD10;
	/*Set number to transfer to length+1 for write operation*/
	I2C1->CR2|=((length+1)<<I2C_CR2_NBYTES_Pos);
	/*Set the mode to write mode*/
	I2C1->CR2&=~I2C_CR2_RD_WRN;
	/*hardware end*/
	I2C1->CR2|=I2C_CR2_AUTOEND;
	/*Generate start*/
	I2C1->CR2|=I2C_CR2_START;
	int i=0;
	while(!(I2C1->ISR & I2C_ISR_STOPF))
	{
		/*Check if TX buffer is empty*/
		if(I2C1->ISR & I2C_ISR_TXE)
		{
			/*send memory address*/
			I2C1->TXDR =send_arr[i] ;
			i++;
		}
	}
	/*Disable I2C*/
	I2C1->CR1 &=~I2C_CR1_PE;
	#endif
}
void I2c::WriteI2c( char adrMemory, char *data, uint16_t length){
	#if defined (STM32F401xE)	||	(STM32F411xE)
	port->CR1 |= (1<<10);  // Enable the ACK
	port->CR1 |= (1<<8);  // Generate START
	while (!(port->SR1 & (1<<0)));  // Wait fror SB bit to set
	port->DR = adr;  //  send the address
	while (!(port->SR1 & I2C_SR1_ADDR));  // wait for ADDR bit to set
	uint8_t temp = port->SR1 | port->SR2;  // read SR1 and SR2 to clear the ADDR bit
	while (!(port->SR1 & (1<<7)));  // wait for TXE bit to set
	port->DR = adrMemory;
	while (!(port->SR1 & (1<<2)));  // wait for BTF bit to set
/**** STEPS FOLLOWED  ************
1. Wait for the TXE (bit 7 in SR1) to set. This indicates that the DR is empty
2. Keep Sending DATA to the DR Register after performing the check if the TXE bit is set
3. Once the DATA transfer is complete, Wait for the BTF (bit 2 in SR1) to set. This indicates the end of LAST DATA transmission
*/	
	while (!(port->SR1 & (1<<7)));  // wait for TXE bit to set 
	while (length)
	{
		while (!(port->SR1 & (1<<7)));  // wait for TXE bit to set 
		port->DR = (uint32_t )*data++;  // send data
		length--;
	}
	
	while (!(port->SR1 & (1<<2)));  // wait for BTF to set
	

	port->CR1 |= I2C_CR1_STOP; //condicion de Stop
	#endif
	#if defined (STM32F767xx) || (STM32F746xx)
	char send_arr[length+1];
	send_arr[0]=adrMemory;
	for (int i=1;(i<length+1);i++)
		{
		send_arr[i]=*data++;
		}


	port->CR1 |=I2C_CR1_PE;

	port->CR2=(adr<<1);

	port->CR2&=~I2C_CR2_ADD10;

	port->CR2|=((length+1)<<I2C_CR2_NBYTES_Pos);

	port->CR2&=~I2C_CR2_RD_WRN;

	port->CR2|=I2C_CR2_AUTOEND;

	port->CR2|=I2C_CR2_START;
	int i=0;
	while(!(port->ISR & I2C_ISR_STOPF))
	{
		if(port->ISR & I2C_ISR_TXE)
		{

			port->TXDR =send_arr[i] ;
			i++;
		}
	}

	port->CR1 &=~I2C_CR1_PE;
	#endif
}
void I2c::WriteI2c(char *data, uint16_t length){
	
	#if defined (STM32F401xE)	||	(STM32F411xE)
	port->CR1 |= (1<<10);  // Enable the ACK
	port->CR1 |= (1<<8);  // Generate START
	while (!(port->SR1 & (1<<0)));  // Wait fror SB bit to set
	
	port->DR = adr;  //  send the address
	while (!(port->SR1 & I2C_SR1_ADDR));  // wait for ADDR bit to set
	uint8_t temp = port->SR1 | port->SR2;  // read SR1 and SR2 to clear the ADDR bit
	

	while (!(port->SR1 & (1<<7)));  // wait for TXE bit to set 
	while (length)
	{
		while (!(port->SR1 & (1<<7)));  // wait for TXE bit to set 
		port->DR = (uint32_t )*data++;  // send data
		length--;
	}
	
	while (!(port->SR1 & (1<<2)));  // wait for BTF to set
	port->CR1 |= I2C_CR1_STOP; //condicion de Stop
	#endif
	
	#if defined (STM32F767xx) || (STM32F746xx)
	port->CR1 |=I2C_CR1_PE;

	port->CR2=(adr<<1);

	port->CR2&=~I2C_CR2_ADD10;

	port->CR2|=(length<<I2C_CR2_NBYTES_Pos);

	port->CR2&=~I2C_CR2_RD_WRN;

	port->CR2|=I2C_CR2_AUTOEND;

	port->CR2|=I2C_CR2_START;
	int i=0;
	while(!(port->ISR & I2C_ISR_STOPF))
	{

		if(port->ISR & I2C_ISR_TXE)
		{

			port->TXDR =*data++ ;
		}
	}

	port->CR1 &=~I2C_CR1_PE;
	#endif
}
char I2c::ReadI2c( char adrMemory){
	#if defined (STM32F401xE)	||	(STM32F411xE)
	port->CR1 |= (1<<10);  // Enable the ACK
	port->CR1 |= (1<<8);  // Generate START
	while (!(port->SR1 & (1<<0)));  // Wait fror SB bit to set
	port->DR = adr;  //  send the address
	while (!(port->SR1 & I2C_SR1_ADDR));  // wait for ADDR bit to set
	uint8_t temp = port->SR1 | port->SR2;  // read SR1 and SR2 to clear the ADDR bit
	while (!(port->SR1 & (1<<7)));  // wait for TXE bit to set
	port->DR = adrMemory;
	while (!(port->SR1 & (1<<2)));  // wait for BTF bit to set
	port->CR1 |= I2C_CR1_STOP; //condicion de Stop
	port->CR1 |= (1<<10);  // Enable the ACK
	port->CR1 |= (1<<8);  // Generate START
	while (!(port->SR1 & (1<<0)));  // Wait fror SB bit to set
	port->DR = adr |1;  //  send the address
	while (!(port->SR1 & (1<<1)));  // wait for ADDR bit to set
	temp = port->SR1 | port->SR2;  // read SR1 and SR2 to clear the ADDR bit
	I2C1->CR1 &= ~I2C_CR1_ACK;
	(void)port->SR2;						// Read SR2
	while (!(port->SR1 & I2C_SR1_RXNE)){};	// Wait for EV7_1
    char value = (char)I2C1->DR;      // Read value
		port->CR1 |=I2C_CR1_ACK;
    port->CR1 |= I2C_CR1_STOP;			    // Generate STOP condition
	return value;
	#endif
	#if defined (STM32F767xx) || (STM32F746xx)
	port->CR2 &=~I2C_CR2_RD_WRN; 
	port->CR2 |=(adr<<1); 
	port->CR2 |=(1<<16); 
	port->CR2 |=I2C_CR2_AUTOEND; 
	port->CR2 |=I2C_CR2_START;  
	while(!(port->ISR & I2C_ISR_TXIS));
	port->TXDR = adrMemory; 
	while (!(port->ISR & I2C_ISR_TXE)); 
	port->CR2|=I2C_CR2_STOP;//Genera STOP	
	while (!(port->ISR & I2C_ISR_STOPF));

	port->CR1 &= ~I2C_CR1_PE;
	while (port->CR1 & I2C_CR1_PE);
	port->CR1 |=I2C_CR1_PE;

	port->CR2 |=(adr<<1);
	port->CR2 |=I2C_CR2_RD_WRN;
	port->CR2 |=(1<<16);
	port->CR2 |=I2C_CR2_START;
	while (!(port->ISR & I2C_ISR_RXNE)); 
	char informacion = I2C2->RXDR;
	while (!(port->ISR & I2C_ISR_STOPF)); 
	port->CR2 |=I2C_CR2_STOP;
	
	port->CR1 &= ~I2C_CR1_PE;
	while (port->CR1 & I2C_CR1_PE);
	port->CR1 |=I2C_CR1_PE; 
	return informacion;
	#endif
}