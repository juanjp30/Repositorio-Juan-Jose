#include "stm32f4xx.h"  // Device header
#include "Reloj.h"
#include "Pines.h"
#include "Usart.h"
#include "Timer.h"
#include "Encoder.h"
#include "PuenteH.h"
#include "stdio.h"
#include "stdint.h" // Para tipos de datos enteros de ancho fijo

/*Informacion de pines*/
/*PINES
ENCODERS
PA0,PA1//Pines Arduino (AP0,AP1)
PA15,PB3//Pines Arduino (PA15,DP3)

Motor A (PB6);		//Pines Arduino (DP10)
Motor B (PA7);		//Pines Arduino (DP11)

Motor A 12 Arduino DP12 PA6
Motor B	13 Arduino DP13 PA5
*/





#ifndef _HEADFILE_H
#define _HEADFILE_H
/*Asignacion de todas las librerias*/

#endif