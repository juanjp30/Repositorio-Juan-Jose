// C�digo Ejemplo 13 3 //
// Archivo *.cpp //
#include "Usart.h"
/*Variables auxiliares para el envio de datos numericos*/
char DatosSendUsart[35];
char ReadUsartString[SizeCharRead];
int auxRecibe=0;

 // Definici�n de funciones apuntadoras a interrupci�n USART RX  // 
FunInt2 FunUsart1=0, FunUsart2=0, FunUsart3=0, FunUsart4=0,
FunUsart5=0, FunUsart6=0, FunUsart7=0, FunUsart8=0;
void ReadStringFun(unsigned char t){
//		if(!(USART3->ISR&USART_ISR_RXNE))return;
//		 // Se ejecuta interrupci�n
		
		if(t!=0x0A){ //DatoVacio
			if(auxRecibe==SizeCharRead){//Contador de datos leidos
			auxRecibe=0;
		}
		if(t!=CharEnd){
			ReadUsartString[auxRecibe]=t;
		}
		auxRecibe++;
		if(t==CharEnd){
			for(int i=auxRecibe-1;i<SizeCharRead;i++){
				ReadUsartString[i]='\0';
			}
			auxRecibe=0;
		}
		
		}
}
extern "C"{ // Rutinas externas
#if defined (STM32F401xE)	||	(STM32F411xE)
  // Vector interrupci�n USART1
 void USART1_IRQHandler(void){
  unsigned int dummy;
  if(!(USART1->SR&USART_SR_RXNE))return;
   // Se ejecuta interrupci�n
  if(FunUsart1!=0)FunUsart1((unsigned char)USART1->DR);
  dummy=USART1->SR; // Se limpian banderas
  dummy=USART1->DR;
 }
 
  // Vector interrupci�n USART2
 void USART2_IRQHandler(void){
  unsigned int dummy;
  if(!(USART2->SR&USART_SR_RXNE))return;
   // Se ejecuta interrupci�n
  if(FunUsart2!=0)FunUsart2((unsigned char)USART2->DR);
  dummy=USART2->SR; // Se limpian banderas
  dummy=USART2->DR;
 }
 
  // Vector interrupci�n USART3
 void USART6_IRQHandler(void){
  unsigned int dummy;
  if(!(USART6->SR&USART_SR_RXNE))return;
     // Se ejecuta interrupci�n   
  if(FunUsart6!=0)FunUsart6((unsigned char)USART6->DR);
  dummy=USART6->SR; // Se limpian banderas
  dummy=USART6->DR;
 }
#endif
#if defined (STM32F767xx) || (STM32F746xx)
  // Vector interrupci�n USART3
 void USART3_IRQHandler(void){
  unsigned int dummy;
  if(!(USART3->ISR&USART_ISR_RXNE))return;
   // Se ejecuta interrupci�n
  if(FunUsart3!=0)FunUsart3((unsigned char)USART3->RDR);
  dummy=USART3->ISR; // Se limpian banderas
  dummy=USART3->RDR;
 }
 
 
 // Vector interrupci�n USART4
 void UART4_IRQHandler(void){
  unsigned int dummy;
  if(!(UART4->ISR&USART_ISR_RXNE))return;
   // Se ejecuta interrupci�n
  if(FunUsart4!=0)FunUsart4((unsigned char)UART4->RDR);
  dummy=UART4->ISR; // Se limpian banderas
  dummy=UART4->RDR;
 } 
 
  // Vector interrupci�n UART5
 void UART5_IRQHandler(void){
  unsigned int dummy;
  if(!(UART5->ISR&USART_ISR_RXNE))return;
   // Se ejecuta interrupci�n
  if(FunUsart5!=0)FunUsart5((unsigned char)UART5->RDR);
  dummy=UART5->ISR; // Se limpian banderas
  dummy=UART5->RDR;
 }
 
  // Vector interrupci�n UART7
 void UART7_IRQHandler(void){
  unsigned int dummy;
  if(!(UART7->ISR&USART_ISR_RXNE))return;
   // Se ejecuta interrupci�n
  if(FunUsart7!=0)FunUsart7((unsigned char)UART7->RDR);
  dummy=UART7->ISR; // Se limpian banderas
  dummy=UART7->RDR;
 }
 
  // Vector interrupci�n UART8
 void UART8_IRQHandler(void){
  unsigned int dummy;
  if(!(UART8->ISR&USART_ISR_RXNE))return;
   // Se ejecuta interrupci�n
  if(FunUsart8!=0)FunUsart8((unsigned char)UART8->RDR);
  dummy=UART8->ISR; // Se limpian banderas
  dummy=UART8->RDR;
 }
#endif 
}
 
 // M�todo para iniciar puerto serial
void Usart::InitUsart(unsigned char rx,unsigned char tx,unsigned int bps){
unsigned long PC;
#if defined (STM32F401xE)	||	(STM32F411xE)
 switch(rx){ // Se eval�a el pin Rx para definir la USART
  case PA10:port=USART1; // PA10 para asignar USART1
   RX.AlternativeFunction(rx,7); // Pin Rx y funci�n alternativa 7
   TX.AlternativeFunction(tx,7); // Pin Tx y funci�n alternativa 7 
   RCC->APB2ENR|=RCC_APB2ENR_USART1EN; // Activa reloj USART1
   PC=PCLK2(); // Leer valor del reloj APB2
   prt=1; // Guarda n�mero del puerto
   break;
  case PA3:port=USART2; // PA3 para asignar USART2
   RX.AlternativeFunction(rx,7); // Pin Rx y funci�n alternativa 7
   TX.AlternativeFunction(tx,7); // Pin Tx y funci�n alternativa 7
   RCC->APB1ENR|=RCC_APB1ENR_USART2EN; // Activa reloj USART2
   PC=PCLK1(); // Leer valor del reloj APB1
   prt=2; // Guarda n�mero del puerto
   break;
  case PA12:port=USART6; // PA12 para asignar USART6
   RX.AlternativeFunction(rx,8); // Pin Rx y funci�n alternativa 8
   TX.AlternativeFunction(tx,8); // Pin Tx y funci�n alternativa 8
   RCC->APB2ENR|=RCC_APB2ENR_USART6EN; // Activa reloj USART6
   PC=PCLK2(); // Leer valor del reloj APB2
   prt=6; // Guarda n�mero del puerto
   break;
  default: return;
}
#endif
 
#if defined (STM32F767xx) || (STM32F746xx)
 switch(rx){ // Se eval�a el pin Rx para definir la USART
  case PA10:
  case PB7:port=USART1; // PA10,PB7 para asignar USART1
   RX.AlternativeFunction(rx,7); // Pin Rx y funci�n alternativa 7
   TX.AlternativeFunction(tx,7); // Pin Tx y funci�n alternativa 7  
   RCC->APB2ENR|=RCC_APB2ENR_USART1EN; // Activa reloj USART1
   PC=PCLK2(); // Leer valor del reloj APB2
   prt=1; // Guarda n�mero del puerto
   break;
  case PA3:
  case PD6:port=USART2; // PA3, PD6 para asignar USART2
   RX.AlternativeFunction(rx,7); // Pin Rx y funci�n alternativa 7
   TX.AlternativeFunction(tx,7); // Pin Tx y funci�n alternativa 7  
   RCC->APB1ENR|=RCC_APB1ENR_USART2EN; // Activa reloj USART2
   PC=PCLK1(); // Leer valor del reloj APB1
   prt=2; // Guarda n�mero del puerto
   break;
  case PD9:port=USART3; // PD9 para asignar USART3
   RX.AlternativeFunction(rx,7); // Pin Rx y funci�n alternativa 7
   TX.AlternativeFunction(tx,7); // Pin Tx y funci�n alternativa 7  
   RCC->APB1ENR|=RCC_APB1ENR_USART3EN; // Activa reloj USART3
   PC=PCLK1(); // Leer valor del reloj APB1
   prt=3; // Guarda n�mero del puerto
   break;
  case PA1:
  case PC11:port=UART4; // PA1, PC11 para asignar UART4
   RX.AlternativeFunction(rx,8); // Pin Rx y funci�n alternativa 8
   TX.AlternativeFunction(tx,8); // Pin Tx y funci�n alternativa 8 
   RCC->APB1ENR|=RCC_APB1ENR_UART4EN; // Activa reloj UART4
   PC=PCLK1(); // Leer valor del reloj APB1
   prt=4; // Guarda n�mero del puerto
   break;   
  case PD2:port=UART5; // PD2 para asignar UART5
   RX.AlternativeFunction(rx,8); // Pin Rx y funci�n alternativa 8
   TX.AlternativeFunction(tx,8); // Pin Tx y funci�n alternativa 8  
   RCC->APB1ENR|=RCC_APB1ENR_UART5EN; // Activa reloj UART5
   PC=PCLK1(); // Leer valor del reloj APB1
   prt=5; // Guarda n�mero del puerto
   break;
  case PC7:
  case PG9:port=USART6; // PC7, PG9 para asignar USART6
   RX.AlternativeFunction(rx,8); // Pin Rx y funci�n alternativa 8
   TX.AlternativeFunction(tx,8); // Pin Tx y funci�n alternativa 8  
   RCC->APB2ENR|=RCC_APB2ENR_USART6EN; // Activa reloj USART6
   PC=PCLK2(); // Leer valor del reloj APB2
   prt=6; // Guarda n�mero del puerto
   break;
  case PE7:
  case PF6:port=UART7; // PE7, PF6 para asignar UART7
   RX.AlternativeFunction(rx,8); // Pin Rx y funci�n alternativa 8
   TX.AlternativeFunction(tx,8); // Pin Tx y funci�n alternativa 8 
   RCC->APB1ENR|=RCC_APB1ENR_UART7EN; // Activa reloj UART7
   PC=PCLK1(); // Leer valor del reloj APB1
   prt=7; // Guarda n�mero del puerto
   break;
  case PE0:port=UART8; // PE0 para asignar UART8
   RX.AlternativeFunction(rx,8); // Pin Rx y funci�n alternativa 8
   TX.AlternativeFunction(tx,8); // Pin Tx y funci�n alternativa 8  
   RCC->APB1ENR|=RCC_APB1ENR_UART8EN; // Activa reloj UART8
   PC=PCLK1(); // Leer valor del reloj APB1
   prt=8; // Guarda n�mero del puerto
   break;
  default: return;
}
#endif
 port->BRR=PC/bps; // Se define la velocidad en BPS
 port->CR1|=(USART_CR1_RE|USART_CR1_TE); // Se habilita Rx y Tx
 port->CR1|=USART_CR1_UE; // Se activa la USART o UART
}
void Usart::InitUsartSTlink(int bps){
	#if defined (STM32F401xE)	||	(STM32F411xE)
	InitUsart(PA3,PA2,bps);
	#endif
	#if defined (STM32F767xx) || (STM32F746xx)
	// M�todo para iniciar Usart 3 para conexion con el pc
	InitUsart(PD9,PD8,bps);
	
	#endif
	
}
// M�todo para enviar Datos Numericos por usart

void Usart::SendDataToUsart(float uno,char t){//Metodo para enviar un dato float
	switch (t)
  {
  	case'I': 
			sprintf(DatosSendUsart,"%d\r\n",int(uno));
  		break;
  	case'D':
			sprintf(DatosSendUsart,"%f\r\n",uno);
  		break;
		case'2': 
			sprintf(DatosSendUsart,"%0.2f\r\n",uno);
  		break;
  	case'3':
			sprintf(DatosSendUsart,"%0.3f\r\n",uno);
  		break;
		case'4':
			sprintf(DatosSendUsart,"%0.4f\r\n",uno);
  		break;
  	default: 
  		break;
  }
	
	int n=0;
  // Transmite datos hasta car�cter nulo  
  while(DatosSendUsart[n]!=0)TxDato(DatosSendUsart[n++]);
	limpiarAuxUsart();
}
void Usart::SendDataToUsart(float uno,float dos,char t){//Metodo para enviar un dato float
	switch (t)
  {
  	case'I': 
			sprintf(DatosSendUsart,"%d,%d\r\n",int(uno),int(dos));
  		break;
  	case'D':
			sprintf(DatosSendUsart,"%f,%f\r\n",uno,dos);
  		break;
		case'2': 
			sprintf(DatosSendUsart,"%0.2f;%0.2f\r\n",uno,dos);
  		break;
  	case'3':
			sprintf(DatosSendUsart,"%0.3f,%0.3f\r\n",uno,dos);
  		break;
		case'4':
			sprintf(DatosSendUsart,"%0.4f,%0.4f\r\n",uno,dos);
  		break;
  	default: 
  		break;
  }
	
	int n=0;
  // Transmite datos hasta car�cter nulo  
  while(DatosSendUsart[n]!=0)TxDato(DatosSendUsart[n++]);
	limpiarAuxUsart();
}
void Usart::SendDataToUsart(float uno,float dos,float tres,char t){//Metodo para enviar un dato float
	switch (t)
  {
  	case'I': 
			sprintf(DatosSendUsart,"%d,%d,%d\r\n",int(uno),int(dos),int(tres));
  		break;
  	case'D':
			sprintf(DatosSendUsart,"%f,%f,%f\r\n",uno,dos,tres);
  		break;
		case'2': 
			sprintf(DatosSendUsart,"%0.2f,%0.2f,%0.2f\r\n",uno,dos,tres);
  		break;
  	case'3':
			sprintf(DatosSendUsart,"%0.3f,%0.3f,%0.3f\r\n",uno,dos,tres);
  		break;
		case'4':
			sprintf(DatosSendUsart,"%0.4f,%0.4f,%0.4f\r\n",uno,dos,tres);
  		break;
  	default: 
  		break;
  }
	
	int n=0;
  // Transmite datos hasta car�cter nulo  
  while(DatosSendUsart[n]!=0)TxDato(DatosSendUsart[n++]);
	limpiarAuxUsart();
}

 // M�todo para transmitir un dato
void Usart::TxDato(unsigned char d){
#if defined (STM32F401xE)	||	(STM32F411xE)
 while(!(port->SR&USART_SR_TXE)); // Se espera buffer disponible
 port->DR=d; // Se transmite dato 
#endif
#if defined (STM32F767xx) || (STM32F746xx)
 while(!(port->ISR&USART_ISR_TXE)); // Se espera buffer disponible
 port->TDR=d; // Se transmite dato
#endif
}
 
bool Usart::RxListo(void){ // M�todo para verificar si llego un dato
  // Se verifica si hay dato disponible
#if defined (STM32F401xE)	||	(STM32F411xE)
 if( port->SR&USART_SR_RXNE )return true;
#endif
#if defined (STM32F767xx) || (STM32F746xx)
 if( port->ISR&USART_ISR_RXNE )return true;
#endif
 return false;
}
 
unsigned char Usart::RxDato(void){ // M�todo para leer un dato
  // Se retorna dato le�do
#if defined (STM32F401xE)	||	(STM32F411xE)
 return port->DR;
#endif
#if defined (STM32F767xx) || (STM32F746xx)
 return port->TDR;
#endif
}
 
 // M�todo para asignar interrupci�n de Rx
void Usart::InterruptionUsart(FunInt2 fun){
 switch(prt){ // Eval�a puerto
  case 1:FunUsart1=fun; // Asigna vector de interrupci�n
   NVIC_EnableIRQ(USART1_IRQn); // Activa interrupci�n
  break;
  case 2:FunUsart2=fun; // Asigna vector de interrupci�n
   NVIC_EnableIRQ(USART2_IRQn); // Activa interrupci�n
  break;
  case 6:FunUsart6=fun; // Asigna vector de interrupci�n
   NVIC_EnableIRQ(USART6_IRQn); // Activa interrupci�n
  break;
#if defined (STM32F767xx) || (STM32F746xx)    
  case 3:FunUsart3=fun; // Asigna vector de interrupci�n
   NVIC_EnableIRQ(USART3_IRQn); // Activa interrupci�n
  break;
  case 4:FunUsart4=fun; // Asigna vector de interrupci�n
   NVIC_EnableIRQ(UART4_IRQn); // Activa interrupci�n
  break;
  case 5:FunUsart5=fun; // Asigna vector de interrupci�n
   NVIC_EnableIRQ(UART5_IRQn); // Activa interrupci�n
  break;
  case 7:FunUsart7=fun; // Asigna vector de interrupci�n
   NVIC_EnableIRQ(UART7_IRQn); // Activa interrupci�n
  break;
  case 8:FunUsart8=fun; // Asigna vector de interrupci�n
   NVIC_EnableIRQ(UART8_IRQn); // Activa interrupci�n
  break;
#endif
 }
  // Activa interrupci�n en puerto
 port->CR1|=USART_CR1_RXNEIE;
}

 // Operador para enviar dato
unsigned char Usart::operator = (unsigned char d){
 TxDato(d); // Transmite dato
 return d; // Retorna dato    
}
 
 // Operador para enviar cadena de texto
void Usart::operator = (char *t){
 int n=0;
  // Transmite datos hasta car�cter nulo  
 while(t[n]!=0)TxDato(t[n++]);  
}
 
 // Operador para esperar un dato
Usart::operator unsigned char(){
 while(!RxListo()); // Espera un dato de entrada
 return RxDato(); // Retorna dato le�do
}
 
 // Operador para asignar interrupci�n de Rx
void Usart::operator = (FunInt2 fun){
 InterruptionUsart(fun);
}
void limpiarAuxUsart(){
	for(int i=0;i<19;i++){
			 DatosSendUsart[i]='\0';
		 }
}


