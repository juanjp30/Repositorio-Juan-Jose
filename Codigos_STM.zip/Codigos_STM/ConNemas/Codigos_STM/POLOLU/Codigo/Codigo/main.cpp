/*CODIGO HECHO POR 
-----------------------
David Alejandro Duarte Montanez
Area de control:
para el proyecto Resilience  
-----------------------
*/
#include "HeadFile.h"
/*Clases Globales*/
Pines LedUno, Boton;
Timer Muestreador;
PuenteH Motor;
Usart Usart;
/*Declaracion de pines globales*/
/*Variables de encoder*/
int ContEncoA = 0, ContEncoB = 0;
/*Variables de tiempo de muestreo*/
long int Time=0;
int contTime=0;
/*Parametros del motor*/
float CajaReductora = 74.83;
int frecuenciaMuestreo = 100;
float ResolucionEnco=48.0;
/*Velocidades [RPM] */
float VelIzq = 0.0, VelDer = 0.0;
/*Variables de control [RPM] */

//Control motor 1
float M1_SetRPM = 0.0;
float M1_U = 0.0, M1_Uk1 = 0.0;
float M1_e = 0.0, M1_ek1 = 0.0;
//Control motor 2
float M2_SetRPM = 0.0;

float M2_U = 0.0, M2_Uk1 = 0.0;
float M2_e = 0.0, M2_ek1 = 0.0;

//LGR para los motores 

float U=0.0,Uk1=0.0;
float e=0.0,ek1=0.0;
float q0=0.3079,q1=-0.1628;

/*Funciones de para el control de los motores*/
void ControlM1(float M1, float Velocity){
	//error 1
	M1_e=M1-Velocity;
	//Control 1
	M1_U=q0*M1_e+q1*M1_ek1+M1_Uk1;
	// Fijar Maximos de ciclo
	// Motor 1
	if(M1_U>100.0){M1_U=100.0;}
	if(M1_U<-100.0){M1_U=-100;}
	//Actualizacion e datos 
	M1_ek1=M1_e;	M1_Uk1=M1_U;
}
void ControlM2(float M2, float Velocity){
	//error 2
	M2_e=M2-Velocity;
	//Control 2
	M2_U=q0*M2_e+q1*M2_ek1+M2_Uk1;
	// Fijar Maximos de ciclo
	// Motor 1
	if(M2_U>100.0){M2_U=100.0;}
	if(M2_U<-100.0){M2_U=-100;}
	//Actualizacion e datos 
	M2_ek1=M2_e;	M2_Uk1=M2_U;
}
void LeerVelocidades (){/*Esta funcion apunta a los set y convierte string to float*/
	sscanf(ReadUsartString, "%f,%f", &M1_SetRPM, &M2_SetRPM);
}
void RPM(void) {
	//Tiempo de ejecucion
	
  Time = contTime * (1.0 / frecuenciaMuestreo) * 1000;
	//Lectura de las RPM
	VelIzq = 0.6 * ((float(Motor.GetAbsolutoA()) * 60.0) / (float(1.0 / frecuenciaMuestreo) * ResolucionEnco * CajaReductora)) + 0.4 * VelIzq;
	Motor.RestConA();
	VelDer = 0.6 * ((float(Motor.GetAbsolutoB()) * 60.0) / (float(1.0 / frecuenciaMuestreo) * ResolucionEnco * CajaReductora)) + 0.4 * VelDer;
	Motor.RestConB();
	//Lectura de los setpots
	//Velocidades();
	//Control del motor y actualizacion del motor
	ControlM1(M1_SetRPM,VelIzq);	Motor.ChangePwmA(M1_U);
	ControlM2(M2_SetRPM,VelDer);	Motor.ChangePwmB(M2_U);

	//Envio por usart
	Usart.SendDataToUsart(Time,M1_SetRPM,M2_SetRPM,'2');
  
  contTime++;//tiempo de muestreo
}





int main(void) {
	//Inicializacion de los sistemas
  Usart.InitUsartSTlink(115200);
	LedUno.UserLed(Led1); LedUno.SetPinDigital(0); //let para probar TM
  Boton.UserButton(); //no hace falta xd
  Motor.InitShieldMotor(1000);
  Muestreador.InitTimer(9,frecuenciaMuestreo,RPM);
	
  while (1) {
		
  }
  return 0;
}