// C�digo Ejemplo 16 3 // 
// Archivo *.cpp //
#include "Timer.h"
#if defined (STM32F401xE)	||	(STM32F411xE)
#include "stm32f4xx.h"                  // Device header

#endif
#if defined (STM32F767xx) || (STM32F746xx)
#include "stm32f7xx.h"                  // Device header
#endif
 // Apuntadores a funciones de interrupci�n 
FunInt FunTim2=0,FunTim3=0,FunTim4=0,FunTim5=0,
FunTim6=0,FunTim7=0,FunTim9=0,FunTim10=0,
FunTim11=0,FunTim12=0,FunTim13=0,FunTim14=0;
extern "C" // Rutinas externas
{
  // Vectores de interrupci�n, limpieza de banderas y ejecuci�n de rutina
 void TIM2_IRQHandler(void){TIM2->SR&=(~TIM_SR_UIF);if(FunTim2!=0)FunTim2();}
 void TIM3_IRQHandler(void){TIM3->SR&=(~TIM_SR_UIF);if(FunTim3!=0)FunTim3();}
 void TIM4_IRQHandler(void){TIM4->SR&=(~TIM_SR_UIF);if(FunTim4!=0)FunTim4();}
 void TIM5_IRQHandler(void){TIM5->SR&=(~TIM_SR_UIF);if(FunTim5!=0)FunTim5();}
 void TIM1_BRK_TIM9_IRQHandler(void){
  TIM9->SR&=(~TIM_SR_UIF);if(FunTim9!=0)FunTim9();}
 void TIM1_UP_TIM10_IRQHandler(void){
  TIM10->SR&=(~TIM_SR_UIF);if(FunTim10!=0)FunTim10();}
 void TIM1_TRG_COM_TIM11_IRQHandler(void){
  TIM11->SR&=(~TIM_SR_UIF);if(FunTim11!=0)FunTim11();}
#if defined (STM32F767xx) || (STM32F746xx)
 void TIM6_DAC_IRQHandler(void){
  TIM6->SR&=(~TIM_SR_UIF);if(FunTim6!=0)FunTim6();}
 void TIM7_IRQHandler(void){
  TIM7->SR&=(~TIM_SR_UIF);if(FunTim7!=0)FunTim7();}
 void TIM8_BRK_TIM12_IRQHandler(void){
  TIM12->SR&=(~TIM_SR_UIF);if(FunTim12!=0)FunTim12();}
 void TIM8_UP_TIM13_IRQHandler(void){
  TIM13->SR&=(~TIM_SR_UIF);if(FunTim13!=0)FunTim13();}
 void TIM8_TRG_COM_TIM14_IRQHandler(void){
  TIM14->SR&=(~TIM_SR_UIF);if(FunTim14!=0)FunTim14();}
#endif
}

 // C�lculo de fuente APB1
unsigned long Timer::APB1(void){
 unsigned long PC;
 PC=HCLK(); // Leer frecuencia del Core
  // Eval�a pre-escala del PCLK1
 switch((RCC->CFGR>>RCC_CFGR_PPRE1_Pos)&7){
  case 4:PC/=2.0;return 2*PC;
  case 5:PC/=4.0;return 2*PC;
  case 6:PC/=8.0;return 2*PC;
  case 7:PC/=16.0;return 2*PC;
  default:return PC;
 }
}

 // C�lculo de fuente APB2
unsigned long Timer::APB2(void){
 unsigned long PC;
 PC=HCLK(); // Leer frecuencia del Core
  // Eval�a pre-escala del PCLK2
 switch((RCC->CFGR>>RCC_CFGR_PPRE2_Pos)&7){
  case 4:PC/=2.0;return 2*PC;
  case 5:PC/=4.0;return 2*PC;
  case 6:PC/=8.0;return 2*PC;
  case 7:PC/=16.0;return 2*PC;
  default:return PC;
 }
}

 // Asigna Timer
void Timer::SetTimer(unsigned char tmr){
 tim=tmr; // Nuemro de Timer
 switch(tim){
  case 1:t=TIM1; // Asigna estructura TIM1
   RCC->APB2ENR|=RCC_APB2ENR_TIM1EN; // Activa reloj TIM
   APB=APB2(); // Lee fuente APB
  break;
  case 2:t=TIM2; // Asigna estructura TIM2
   RCC->APB1ENR|=RCC_APB1ENR_TIM2EN; // Activa reloj TIM
   APB=APB1(); // Lee fuente APB
  break;
  case 3:t=TIM3; // Asigna estructura TIM3
   RCC->APB1ENR|=RCC_APB1ENR_TIM3EN; // Activa reloj TIM
   APB=APB1(); // Lee fuente APB
  break;
  case 4:t=TIM4; // Asigna estructura TIM4
   RCC->APB1ENR|=RCC_APB1ENR_TIM4EN; // Activa reloj TIM
   APB=APB1(); // Lee fuente APB
  break;
  case 5:t=TIM5; // Asigna estructura TIM5
   RCC->APB1ENR|=RCC_APB1ENR_TIM5EN; // Activa reloj TIM
   APB=APB1(); // Lee fuente APB
  break;
  case 9:t=TIM9; // Asigna estructura TIM9
   RCC->APB2ENR|=RCC_APB2ENR_TIM9EN; // Activa reloj TIM
   APB=APB2(); // Lee fuente APB
  break;
  case 10:t=TIM10; // Asigna estructura TIM10
   RCC->APB2ENR|=RCC_APB2ENR_TIM10EN; // Activa reloj TIM
   APB=APB2(); // Lee fuente APB
  break;
  case 11:t=TIM11; // Asigna estructura TIM11
   RCC->APB2ENR|=RCC_APB2ENR_TIM11EN; // Activa reloj TIM
   APB=APB2(); // Lee fuente APB
  break;

#if defined (STM32F767xx) || (STM32F746xx)
  case 6:t=TIM6; // Asigna estructura TIM6
   RCC->APB1ENR|=RCC_APB1ENR_TIM6EN; // Activa reloj TIM
   APB=APB1(); // Lee fuente APB
  break;
  case 7:t=TIM7; // Asigna estructura TIM7
   RCC->APB1ENR|=RCC_APB1ENR_TIM7EN; // Activa reloj TIM
   APB=APB1(); // Lee fuente APB
  break;
  case 8:t=TIM8; // Asigna estructura TIM8
   RCC->APB2ENR|=RCC_APB2ENR_TIM8EN; // Activa reloj TIM
   APB=APB2(); // Lee fuente APB
  break;
  case 12:t=TIM12; // Asigna estructura TIM12
   RCC->APB1ENR|=RCC_APB1ENR_TIM12EN; // Activa reloj TIM
   APB=APB1(); // Lee fuente APB
  break;
  case 13:t=TIM13; // Asigna estructura TIM13
   RCC->APB1ENR|=RCC_APB1ENR_TIM13EN; // Activa reloj TIM
   APB=APB1(); // Lee fuente APB
  break;
  case 14:t=TIM14; // Asigna estructura TIM14
   RCC->APB1ENR|=RCC_APB1ENR_TIM14EN; // Activa reloj TIM
   APB=APB1(); // Lee fuente APB
  break;
#endif
 }
 t->CNT=0xFFFFFFFF; // Valor inicial del contador
 t->CR1|=TIM_CR1_CEN; // Encendido del TIM
}
void Timer::InitTimer(unsigned char tmr,double Ft,FunInt fun){
	SetTimer(tmr);
	SetFrecuencia(Ft);
	Interrpcion(fun);
}
double Timer::GetPeriodo(void){ // Lee periodo
  // Retorna c�lculo del periodo
 return (t->PSC+1)*(t->ARR+1)/(double)APB;
}

void Timer::SetPeriodo(double Tt){ // Asigna periodo
 unsigned int PSC_ARR;
  // Asigna PSC y ARR asumiendo que son iguales
 PSC_ARR=sqrtf(Tt*APB)-1;
 t->ARR=PSC_ARR;
 t->PSC=PSC_ARR;
 t->CNT=0xFFFFFFFF; // Valor inicial del contador
}

double Timer::GetFrecuencia(void){ // Lee frecuencia
 return 1.0/GetPeriodo(); // Retorna frecuencia
}
 
void Timer::SetFrecuencia(double Ft){ // Asigna frecuencia
 SetPeriodo(1.0/Ft); // Asigna frecuencia
}

 // Asigna interrupci�n
void Timer::Interrpcion(FunInt fun){
 switch(tim){ // Eval�a n�mero del TIM
  case 2:FunTim2=fun; // Asigna apuntador de funci�n
   NVIC_EnableIRQ(TIM2_IRQn); // Activa interrupci�n
  break;
  case 3:FunTim3=fun; // Asigna apuntador de funci�n
   NVIC_EnableIRQ(TIM3_IRQn); // Activa interrupci�n
  break;
  case 4:FunTim4=fun; // Asigna apuntador de funci�n
   NVIC_EnableIRQ(TIM4_IRQn); // Activa interrupci�n
  break;
  case 5:FunTim5=fun; // Asigna apuntador de funci�n
   NVIC_EnableIRQ(TIM5_IRQn); // Activa interrupci�n
  break;
  case 9:FunTim9=fun; // Asigna apuntador de funci�n
   NVIC_EnableIRQ(TIM1_BRK_TIM9_IRQn); // Activa interrupci�n
  break;
  case 10:FunTim10=fun; // Asigna apuntador de funci�n
   NVIC_EnableIRQ(TIM1_UP_TIM10_IRQn); // Activa interrupci�n
  break;
  case 11:FunTim11=fun; // Asigna apuntador de funci�n
   NVIC_EnableIRQ(TIM1_TRG_COM_TIM11_IRQn); // Activa interrupci�n
  break;
#if defined (STM32F767xx) || (STM32F746xx)
  case 6:FunTim6=fun; // Asigna apuntador de funci�n
   NVIC_EnableIRQ(TIM6_DAC_IRQn); // Activa interrupci�n
  break;
  case 7:FunTim7=fun; // Asigna apuntador de funci�n
   NVIC_EnableIRQ(TIM7_IRQn); // Activa interrupci�n
  break;
  case 12:FunTim12=fun; // Asigna apuntador de funci�n
   NVIC_EnableIRQ(TIM8_BRK_TIM12_IRQn); // Activa interrupci�n
  break;
  case 13:FunTim13=fun; // Asigna apuntador de funci�n
   NVIC_EnableIRQ(TIM8_UP_TIM13_IRQn); // Activa interrupci�n
  break;
  case 14:FunTim14=fun; // Asigna apuntador de funci�n
   NVIC_EnableIRQ(TIM8_TRG_COM_TIM14_IRQn); // Activa interrupci�n
  break;
#endif
  default: return;
 }
 t->DIER|=TIM_DIER_UIE; // Enciende interrupci�n TIM
}

double Timer::operator = (double Tt){ // Asigna periodo
 SetPeriodo(Tt); // Asigna periodo
 return Tt; // Retorna valor Tt
}

 // Asigna interrupci�n
void Timer::operator = (FunInt fun){
 Interrpcion(fun); // Asigna interrupci�n
}