// C�digo Ejemplo 16 6 // 
// Archivo *.h //
#ifndef _PWM_H
#define _PWM_H
#include "Timer.h" 
// *** Clase Pwm *** //
class Pwm : public Timer{
private:
 unsigned char Can; 
 float frecuencia;
 float periodo;
public:
 Pwm(); // Constructor    
 void IniciarPwm(unsigned char tmr,double fre); // M�todo para iniciar PWM
 void PinCanal(unsigned char pin); // M�todo para configurar pin
 void ActivarCanal(unsigned char can); // M�todo para activar canal
 void InvertirPolaridad(void); // M�todo para invertir la polaridad del canal
 void SetPwm(unsigned char can,double duty); // M�todo para ajustar ciclo �til
};
#endif



