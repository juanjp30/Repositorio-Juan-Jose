// C�digo Ejemplo 16 7 // 
// Archivo *.cpp //
#include "Pwm.h"

Pwm::Pwm(){Can=255;} // Constructor 
 // M�todo para iniciar PWM
void Pwm::IniciarPwm(unsigned char tmr,double fre){
 SetTimer(tmr); // Inicio Timer
 SetFrecuencia(fre); // Ajuste de frecuencia
 periodo=GetPeriodo();
 frecuencia=GetFrecuencia();
  // Apagado de todos los canales PWM
 t->CCR1=0;
 t->CCR2=0;
 t->CCR3=0;
 t->CCR4=0;
}
 
 // M�todo para configurar pin
void Pwm::PinCanal(unsigned char pin){
 Pines P;
  // Se inicia pin en funci�n alternativa 
  // seg�n el n�mero del Timer
 switch(tim){
  case 1:P.AlternativeFunction(pin,0x01);break;
  case 2:P.AlternativeFunction(pin,0x01);break;
  case 3:P.AlternativeFunction(pin,0x02);break;
  case 4:P.AlternativeFunction(pin,0x02);break;
  case 5:P.AlternativeFunction(pin,0x02);break;
  default:P.AlternativeFunction(pin,0x03);break;
 }
}
 
 // M�todo para invertir la polaridad del canal
void Pwm::InvertirPolaridad(void){
  // Invierte los bit de polaridad
 switch(Can){
  case 1:t->CCER^=TIM_CCER_CC1P;break;
  case 2:t->CCER^=TIM_CCER_CC2P;break;
  case 3:t->CCER^=TIM_CCER_CC3P;break;
  case 4:t->CCER^=TIM_CCER_CC4P;break;
 }
}
 
 // M�todo para activar canal
void Pwm::ActivarCanal(unsigned char can){
 Can=can;    
  // Seg�n el canal se configura la salida PWM
 switch(can){
  case 1:
   t->CCMR1|=(7UL<<TIM_CCMR1_OC1M_Pos); // Modo PWM
   t->CCMR1|=TIM_CCMR1_OC1PE; // Comparador activo
   t->CCER|=(TIM_CCER_CC1P|TIM_CCER_CC1E);
  break;
  case 2:
   t->CCMR1|=(7UL<<TIM_CCMR1_OC2M_Pos); // Modo PWM
   t->CCMR1|=TIM_CCMR1_OC2PE; // Comparador activo
   t->CCER|=(TIM_CCER_CC2P|TIM_CCER_CC2E);
  break;
  case 3:
   t->CCMR2|=(7UL<<TIM_CCMR2_OC3M_Pos); // Modo PWM
   t->CCMR2|=TIM_CCMR2_OC3PE; // Comparador activo
   t->CCER|=(TIM_CCER_CC3P|TIM_CCER_CC3E);
  break;
  case 4:
   t->CCMR2|=(7UL<<TIM_CCMR2_OC4M_Pos); // Modo PWM
   t->CCMR2|=TIM_CCMR2_OC4PE; // Comparador activo
   t->CCER|=(TIM_CCER_CC4P|TIM_CCER_CC4E);
  break;
 }
 t->CR1|=TIM_CR1_ARPE; // Recarga activa
 t->CR1|=TIM_CR1_CEN; // Activo modulo comparador
 t->BDTR|=TIM_BDTR_MOE; // Outputs activos
 SetPwm(can,0); // Canal 0%
}
 
 // M�todo para ajustar ciclo �til
void Pwm::SetPwm(unsigned char can,double duty){
 unsigned int CCR; // Variable de calculo
 CCR = t->ARR*(duty)/100.0; // Calculo del ciclo �til
 switch(can){ // Asignaci�n del ciclo �til al canal can
  case 1:t->CCR1=CCR;break;
  case 2:t->CCR2=CCR;break;
  case 3:t->CCR3=CCR;break;
  case 4:t->CCR4=CCR;break;
 }
}